void filled_pentagon(int row, int colour, char symbol,int position);
void hollow_pentagon(int row, int colour, char symbol,int position);