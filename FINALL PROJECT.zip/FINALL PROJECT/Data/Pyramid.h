void filled_reverse_pyramid(int row, int colour, char symbol, int position);
void hollow_reverse_pyramid(int row, int colour, char symbol, int position);
void filled_pyramid(int row, int colour, char symbol, int position);
void hollow_pyramid(int row, int colour, char symbol, int position);