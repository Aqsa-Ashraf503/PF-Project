void filled_diamond(int row, int colour, char symbol, int position);
void hollow_diamond(int row, int colour, char symbol, int position);