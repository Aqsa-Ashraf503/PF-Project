void filled_circle(int radius, int colour, char symbol,int position,int choice);
void hollow_circle(int radius, int colour, char symbol,int position,int choice);