#include "Data_header.h"


// Functions to input the size,symbl,colour
void horizontal_line(int row, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
    
// for left
if (position == 1)
    {
        
        for(i = 1; i <= row; i++) 
        
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  
                printf("\033[0m");
         
        }
        printf("\n");    
     
}
    
// for right
if (position == 2)
    {
        
        for(i = 1; i <= row; i++)
        {
            
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  
                printf("\033[0m");
          
        }
         {
             printf("                                                                                                   ");
        
        
         printf("\n");
         
                 
}

    }
    //for middle
    if (position == 3)

    {
        
        for(i = 1; i <= row; i++)
         {
            
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  
                printf("\033[0m");
          
        }
printf("                                                 ");
         
        
         printf("\n");
         
                  


    }
}

    
// Functions to input the size,symbl,colour
void vertical_line(int row, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
        
    for (int i = 1; i <= row; i++) {
        
       {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  
                printf("\033[0m");
                printf("\n");          
}
            }
            printf("\n");         
             

        }
       


// for right
if (position == 2)
{
    
    for (int i = 1; i <= row; i++) {
                     printf("                                                                                                   ");
        
      {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  
                printf("\033[0m");
                 printf("\n");          

            }
           
        }
        printf("\n");        
         
          
}

//for middle
if (position == 3)
{
    
    for (int i = 1; i <= row; i++) {
          printf("                                                 ");
          
         {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  
                printf("\033[0m");
                 printf("\n");          

            }
            
        }
        printf("\n");       
           


}
}






void print_character1(int row, int colour, char symbol,int position, char choice)
{
    switch (choice)
    {
    case '1':
       horizontal_line(row, colour, symbol,position);
        break;
    case '2':
        vertical_line(row,colour, symbol,position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}
    
