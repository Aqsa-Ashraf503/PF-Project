#include "Data_header.h"
// Functions to input the size,symbl,colour
void plus_sign(int row, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
        
    for(int i=1;i<=row;i++)  
  {  
    if(i==((row/2)+1))  
    {  
      for(int j=1;j<=row;j++)  
        
         {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");
            }     
    }  
    else  
    {  
    for(int j=1;j<=row/2;j++)  
    {  
      printf(" "); 
     
    }  
    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");  
    }  
    printf("\n");  
    
  }  
}

// for right
if (position == 2)
{
    
    for(int i=1;i<=row;i++)  {
     printf("                                                                                                   ");
        
    if(i==((row/2)+1))  
    {  
      for(int j=1;j<=row;j++)  
      {  
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");  
      }  
   
    }  
    else  
    {  
    for(int j=1;j<=row/2;j++)  
     
      {  
      printf(" "); 
     
    }  
    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");  
    }  
    printf("\n");
     
    }
}
//for middle
if (position == 3)
{
    
    for(int i=1;i<=row;i++)   {
          printf("                                                 ");
          if(i==((row/2)+1))  
    {  
      for(int j=1;j<=row;j++)  
      {  
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");  
      }  
   
    }  
    else  
    {  
    for(int j=1;j<=row/2;j++)  
    {  
      printf(" ");  
      
    }  
    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");  
    }  
    printf("\n"); 
     
}
}
}

