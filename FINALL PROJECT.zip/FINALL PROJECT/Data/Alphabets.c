#include "Data_header.h"
void char_of_A(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int width = 2 * size - 1;
    int n = width / 2;
    // for left
    if (position == 1)
    {
        for (i = 0; i < size; i++)
        {
            for (j = 0; j <= width; j++)
            {
                if (j == n || j == (width - n) || (i == size / 2 && j > n && j < (width - n)))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
            n--;
        }
       
    }
    // for right
    if (position == 2)
    {
       
        for (i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (j = 0; j <= width; j++)
            {
                if (j == n || j == (width - n) || (i == size / 2 && j > n && j < (width - n)))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
            n--;
        }
       
    }
    // for middle
    if (position == 3)
    {
       
        for (i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (j = 0; j <= width; j++)
            {
                if (j == n || j == (width - n) || (i == size / 2 && j > n && j < (width - n)))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
            n--;
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_B(int size, int col, int colour, char symbol, int position)
{
    // intializing the Aariables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("b.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if ((j == 0 || i == 0 || i == size - 1 || i == size / 2) && j < size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == size - 1 && (i > 0 && i < size - 1))
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for right
    if (position == 2)
    {
        FILE *done = fopen("b.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if ((j == 0 || i == 0 || i == size - 1 || i == size / 2) && j < size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == size - 1 && (i > 0 && i < size - 1))
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("b.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if ((j == 0 || i == 0 || i == size - 1 || i == size / 2) && j < size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == size - 1 && (i > 0 && i < size - 1))
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_C(int size, int col, int colour, char symbol, int position)
{
    // intializing the Aariables
    int i;
    int j;
    int width = size;
    // outer loop for the letter C
    if (position == 1)
    {
        FILE *done = fopen("c.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < width; j++)
            {
                if ((i == 0 || i == size - 1) && j < width - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == 0)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("c.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < width; j++)
            {
                if ((i == 0 || i == size - 1) && j < width - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == 0)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for middle
    if (position == 3)
    {
        FILE *done = fopen("c.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < width; j++)
            {
                if ((i == 0 || i == size - 1) && j < width - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == 0)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_D(int size, int col, int colour, char symbol, int position)
{
    // intializing the Aariables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("d.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j <= size; j++)
            {
                if (j == 0 || (j < size && (i == 0 || i == size - 1)) || (j == size && i != 0 && i != size - 1))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("d.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j <= size; j++)
            {
                if (j == 0 || (j < size && (i == 0 || i == size - 1)) || (j == size && i != 0 && i != size - 1))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("d.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j <= size; j++)
            {
                if (j == 0 || (j < size && (i == 0 || i == size - 1)) || (j == size && i != 0 && i != size - 1))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_E(int size, int col, int colour, char symbol, int position)
{
    // intializing the Aariables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("e.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("\033[0;%d;40m", colour);
            printf("%c", symbol);
            
            printf("\033[0m");
            for (int j = 0; j < size; j++)
            {
                if ((i == 0 || i == size - 1) || (i == size / 2))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("e.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            printf("\033[0;%d;40m", colour);
            printf("%c", symbol);
            
            printf("\033[0m");
            for (int j = 0; j < size; j++)
            {
                if ((i == 0 || i == size - 1) || (i == size / 2))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("e.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            printf("\033[0;%d;40m", colour);
            printf("%c", symbol);
            
            printf("\033[0m");
            for (int j = 0; j < size; j++)
            {
                if ((i == 0 || i == size - 1) || (i == size / 2))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}
void char_of_F(int size, int col, int colour, char symbol, int position)
{
    // intializing the Aariables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("f.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if ((j == 0) || (i == 0) || (i == size / 2 && j <= size / 2))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("f.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if ((j == 0) || (i == 0) || (i == size / 2 && j <= size / 2))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("f.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if ((j == 0) || (i == 0) || (i == size / 2 && j <= size / 2))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

void char_of_G(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
        FILE *done = fopen("g.text", "w");
        for (i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if ((i == 0 && (j > 0 && j < size - 1)) ||
                    (i == size - 1 && (j > 0 && j < size)) ||
                    (j == 0 && (i > 0 && i < size - 1)) ||
                    (j == size - 1 && (i >= size / 2)) ||
                    (i == size / 2 && (j >= size / 2)))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("g.text", "w");
        for (i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if ((i == 0 && (j > 0 && j < size - 1)) ||
                    (i == size - 1 && (j > 0 && j < size)) ||
                    (j == 0 && (i > 0 && i < size - 1)) ||
                    (j == size - 1 && (i >= size / 2)) ||
                    (i == size / 2 && (j >= size / 2)))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("g.text", "w");
        for (i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if ((i == 0 && (j > 0 && j < size - 1)) ||
                    (i == size - 1 && (j > 0 && j < size)) ||
                    (j == 0 && (i > 0 && i < size - 1)) ||
                    (j == size - 1 && (i >= size / 2)) ||
                    (i == size / 2 && (j >= size / 2)))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_H(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("h.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || j == size - 1 || i == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for right
    if (position == 2)
    {
        FILE *done = fopen("h.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || j == size - 1 || i == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("h.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || j == size - 1 || i == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_I(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // outer loop for the letter X
    if (position == 1)
    {
        FILE *done = fopen("i.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || i == size - 1 || j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("i.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || i == size - 1 || j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for middle
    if (position == 3)
    {
        FILE *done = fopen("i.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || i == size - 1 || j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_J(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("j.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || (j == size - 1 && i < size - 1) || (i == size - 1 && j <= size / 2) || (i >= size / 2 && j == 0))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("j.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || (j == size - 1 && i < size - 1) || (i == size - 1 && j <= size / 2) || (i >= size / 2 && j == 0))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("j.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || (j == size - 1 && i < size - 1) || (i == size - 1 && j <= size / 2) || (i >= size / 2 && j == 0))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_K(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("k.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || i + j == size / 2 || i - j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("k.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || i + j == size / 2 || i - j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("k.text", "w");

        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || i + j == size / 2 || i - j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

void char_of_L(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("l.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || i == size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("l.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || i == size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("l.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (j == 0 || i == size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}
void char_of_M(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
       
        for (i = 1; i <= size; i++)
        {
            for (j = 1; j <= size; j++)
            {
                if (j == 1 || j == size || (i == j && j <= size / 2 + 1) || (j == size - i + 1 && j > size / 2))
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        
        }
       
    }
    // for right
    if (position == 2)
    {
       
        for (i = 1; i <= size; i++)
        {
            printf("                                                                                                    ");
            for (j = 1; j <= size; j++)
            {
                if (j == 1 || j == size || (i == j && j <= size / 2 + 1) || (j == size - i + 1 && j > size / 2))
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        
        }
       
    }
    // for middle
    if (position == 3)
    {
       
        for (i = 1; i <= size; i++)
        {
            printf("                                                  ");
            for (j = 1; j <= size; j++)
            {
                if (j == 1 || j == size || (i == j && j <= size / 2 + 1) || (j == size - i + 1 && j > size / 2))
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           

        }
       
    }
}
void char_of_N(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
       
        for (i = 0; i < size; i++)
        {
            for (j = 0; j < size; j++)
            {
                if (j == 0 || j == size-1 || i == j )
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        
        }
       
    }
    // for right
    if (position == 2)
    {
       
        for (i = 0; i < size; i++)
        {
            printf("                                                                                                    ");
            for (j = 0; j < size; j++)
            {
                if (j == 1 || j == size || i == j )
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        
        }
       
    }
    // for middle
    if (position == 3)
    {
       
        for (i = 0; i < size; i++)
        {
            printf("                                                  ");
            for (j = 0; j < size; j++)
            {
                if (j == 1 || j == size || i == j )
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           

        }
       
    }
}




void char_of_O(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
        FILE *done = fopen("o.text", "w");
        for (i = 1; i <= size; i++)
        {
            for (j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("o.text", "w");
        for (i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("o.text", "w");
        for (i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_P(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("p.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (j == 1 || i == 1 && j != size || i == size / 2 && j != size || j == size && i != 1 && i != size / 2 && i < size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for right
    if (position == 2)
    {
        FILE *done = fopen("p.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (j == 1 || i == 1 && j != size || i == size / 2 && j != size || j == size && i != 1 && i != size / 2 && i < size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("p.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (j == 1 || i == 1 && j != size || i == size / 2 && j != size || j == size && i != 1 && i != size / 2 && i < size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_Q(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // outer loop for the letter Q
    if (position == 1)
    {
        FILE *done = fopen("q.text", "w");
        for (i = 1; i <= size; i++)
        {
            for (j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size || i > size / 2 && i == j)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("q.text", "w");
        for (i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size || i > size / 2 && i == j)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for middle
    if (position == 3)
    {
        FILE *done = fopen("q.text", "w");
        for (i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size || i > size / 2 && i == j)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_R(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // outer loop for the letter R
    if (position == 1)
    {
        FILE *done = fopen("r.text", "w");
        for (i = 1; i <= size; i++)
        {
            // printing colours
            printf("\033[0;%d;40m", colour);
            printf("%c", symbol);
            
            printf("\033[0m");
            for (int j = 1; j <= size; j++)
            {
                if ((i == 1 || i == size / 2 + 1) && j < size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == size && i != 1 && i <= size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == i && i > size / 2 + 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("r.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            // printing colours
            printf("\033[0;%d;40m", colour);
            printf("%c", symbol);
            
            printf("\033[0m");
            for (int j = 1; j <= size; j++)
            {
                if ((i == 1 || i == size / 2 + 1) && j < size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == size && i != 1 && i <= size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == i && i > size / 2 + 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for middle
    if (position == 3)
    {
        FILE *done = fopen("r.text", "w");
        for (i = 1; i <= size; i++)
        {
            printf("                                                 ");
            // printing colours
            printf("\033[0;%d;40m", colour);
            printf("%c", symbol);
            
            printf("\033[0m");
            for (int j = 1; j <= size; j++)
            {
                if ((i == 1 || i == size / 2 + 1) && j < size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == size && i != 1 && i <= size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (j == i && i > size / 2 + 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_S(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int width = size;
    int height = size;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("s.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= width; j++)
            {
                if ((i == 1 || i == height || i == height / 2 + 1) ||
                    (i < height / 2 + 1 && j == 1) ||
                    (i > height / 2 + 1 && j == width))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("s.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= width; j++)
            {
                if ((i == 1 || i == height || i == height / 2 + 1) ||
                    (i < height / 2 + 1 && j == 1) ||
                    (i > height / 2 + 1 && j == width))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("s.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= width; j++)
            {
                if ((i == 1 || i == height || i == height / 2 + 1) ||
                    (i < height / 2 + 1 && j == 1) ||
                    (i > height / 2 + 1 && j == width))
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_T(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("t.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (j = 0; j < size; j++)
            {
                if (i == 0 || j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("t.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (j = 0; j < size; j++)
            {
                if (i == 0 || j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("t.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (j = 0; j < size; j++)
            {
                if (i == 0 || j == size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_U(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int width = size;

    // for left
    if (position == 1)
    {
        FILE *done = fopen("u.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= width; j++)
            {
                if ((j == 1 || j == width) && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (i == size)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("u.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= width; j++)
            {
                if ((j == 1 || j == width) && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (i == size)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("u.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= width; j++)
            {
                if ((j == 1 || j == width) && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else if (i == size)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

void char_of_V(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
        FILE *done = fopen("v.text", "w");
        for (i = 0; i < size; i++)
        {
            for (j = 0; j < 2 * size; j++)
            {
                if (i == j || i + j == 2 * size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("v.text", "w");
        for (i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (j = 0; j < 2 * size; j++)
            {
                if (i == j || i + j == 2 * size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("v.text", "w");
        for (i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (j = 0; j < 2 * size; j++)
            {
                if (i == j || i + j == 2 * size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_W(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("w.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size * 4; j++)
            {
                if (j == i || j == size * 2 - i || j == size * 2 + i || j == size * 4 - i - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for right
    if (position == 2)
    {
        FILE *done = fopen("w.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size * 4; j++)
            {
                if (j == i || j == size * 2 - i || j == size * 2 + i || j == size * 4 - i - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("w.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size * 4; j++)
            {
                if (j == i || j == size * 2 - i || j == size * 2 + i || j == size * 4 - i - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_X(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // outer loop for the letter X
    if (position == 1)
    {
        FILE *done = fopen("x.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (i == j || i + j == size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("x.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (i == j || i + j == size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for middle
    if (position == 3)
    {
        FILE *done = fopen("x.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (i == j || i + j == size - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_Y(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("y.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (j == size / 2 && i >= size / 2 ||
                    i == j && j <= size / 2 ||
                    i + j == size - 1 && j >= size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("y.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (j == size / 2 && i >= size / 2 ||
                    i == j && j <= size / 2 ||
                    i + j == size - 1 && j >= size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("y.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (j == size / 2 && i >= size / 2 ||
                    i == j && j <= size / 2 ||
                    i + j == size - 1 && j >= size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void char_of_Z(int size, int col, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("z.text", "w");
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || i == size - 1 || j == size - i - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("z.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || i == size - 1 || j == size - i - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("z.text", "w");
        for (int i = 0; i < size; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < size; j++)
            {
                if (i == 0 || i == size - 1 || j == size - i - 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}
