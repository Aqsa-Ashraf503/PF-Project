#include "Data_header.h"

void filled_diamond(int row, int colour, char symbol, int position){


    if (position == 1)
    {

        
        for (int i = row; i >= -row; i--)
        {
           
            for (int j = 1; j <= abs(i); j++)
            {
                printf(" ");
            }
            for (int k = row; k >= abs(i); k--)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    if (position == 2)
    {

        for (int i = row; i >= -row; i--)
        {
            printf("                                                                                         ");

            for (int j = 1; j <= abs(i); j++)
            {
                printf(" ");
            }
            for (int k = row; k >= abs(i); k--)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    if (position == 3)
    {

        for (int i = row; i >= -row; i--)
        {
            printf("                                          ");
            for (int j = 1; j <= abs(i); j++)
            {
                printf(" ");
            }
            for (int k = row; k >= abs(i); k--)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
}
void hollow_diamond(int row, int colour, char symbol, int position)
{
    if (position == 1)
    {

        for (int i = row; i >= -row; i--)
        {
            for (int j = 1; j <= abs(i); j++)
            {
                printf(" ");
            }
            for (int k = row; k >= abs(i); k--)
            {
                if (k == abs(i) || k == row)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  ");

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    if (position == 2)
    {

        for (int i = row; i >= -row; i--)
        {
            printf("                                                                                                 ");
            for (int j = 1; j <= abs(i); j++)
            {
                printf(" ");
            }
            for (int k = row; k >= abs(i); k--)
            {
                if (k == abs(i) || k == row)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  ");

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    if (position == 3)
    {

        for (int i = row; i >= -row; i--)
        {
            printf("                                           ");
            for (int j = 1; j <= abs(i); j++)
            {
                printf(" ");
            }
            for (int k = row; k >= abs(i); k--)
            {
                if (k == abs(i) || k == row)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  ");

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
}