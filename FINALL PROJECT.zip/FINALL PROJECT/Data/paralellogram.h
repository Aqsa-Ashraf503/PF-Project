void filled_paralellogram(int row,int column, int colour, char symbol,int position);
void hollow_paralellogram(int row,int column, int colour, char symbol,int position);