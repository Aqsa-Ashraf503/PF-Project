#include "Data_header.h"
// Functions to input the n,symbl,colour
void filled_heart(int n, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
        
        for (i = n / 2; i <= n; i += 2)
    {
        for (j = 1; j < n - i; j += 2)
            printf(" ");
          

        for (j = 1; j <= i; j++)
        {
           // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }
        for (j = 1; j <= n - i; j++)
            printf(" ");
          

        for (j = 1; j <= i; j++)
        {
            // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }
        printf("\n");
     
    }

    for (i = n; i >= 1; i--)
    {
        for (j = i; j < n; j++)
            printf(" ");

        for (j = 1; j <= (i * 2) - 1; j++)
        {
            // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }

        printf("\n");
     
    }
    }
// for right
if (position == 2)
    {
          
         for (i = n / 2; i <= n; i += 2){
            
            printf("                                                                                                   ");
          
              for (j = 1; j < n - i; j += 2)
            printf(" ");
          
             for (j = 1; j <= i; j++)
        {
           // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }
        for (j = 1; j <= n - i; j++)
            printf(" ");
          

        for (j = 1; j <= i; j++)
        {
            // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }
        printf("\n");
     
    }

    for (i = n; i >= 1; i--)
    {
        
            printf("                                                                                                   ");
          
        for (j = i; j < n; j++)
            printf(" ");
          

        for (j = 1; j <= (i * 2) - 1; j++)
        {
            // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }

        printf("\n");
     
    }
    }
    //for middle
    if (position == 3)
    {
        
         for (i = n / 2; i <= n; i += 2){
printf("                                                 ");
        for (j = 1; j < n - i; j += 2)
            printf(" ");
          
             
        for (j = 1; j <= i; j++)
        {
           // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }
        for (j = 1; j <= n - i; j++)
            printf(" ");
          

        for (j = 1; j <= i; j++)
        {
            // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }
        printf("\n");
     
}
for (i = n; i >= 1; i--)
    {
        printf("                                                 ");
 
        for (j = i; j < n; j++)
            printf(" ");
          

        for (j = 1; j <= (i * 2) - 1; j++)
        {
            // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
        }

        printf("\n");
     
    }
    }
}
    
// Functions to input the n,symbl,colour
void hollow_heart(int n, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
    
    for (i = n/2; i <= n; i += 2) {
        for (j = 1; j < n-i; j += 2)
            printf(" ");
          

        for (j = 1; j <= i; j++) {
            if (j == 1 || j == i)
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        for (j = 1; j <= n-i; j++)
            printf(" ");

        for (j = 1; j <= i; j++) {
            if (j == 1 || j == i)
               {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
               }
            else
                printf(" ");
              
        }

        printf("\n");
     
    }

    for (i = n; i >= 1; i--) {
        for (j = i; j < n; j++)
            printf(" ");
          

        for (j = 1; j <= (i * 2) - 1; j++) {
            if (j == 1 || j == (i * 2) - 1)
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        printf("\n");
     
    }
}

// for right
if (position == 2)
{
    
    for (i = n/2; i <= n; i += 2) {
                     printf("                                                                                                   ");
        
        for (j = 1; j < n-i; j += 2)
            printf(" ");
          

        for (j = 1; j <= i; j++) {
            if (j == 1 || j == i)
                {
                        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        for (j = 1; j <= n-i; j++)
            printf(" ");
          

        for (j = 1; j <= i; j++) {
            if (j == 1 || j == i)
                {
                        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        printf("\n");
     
    }
    for (i = n; i >= 1; i--) {
          printf("                                                                                                   ");
        for (j = i; j < n; j++)
            printf(" ");

        for (j = 1; j <= (i * 2) - 1; j++) {
            if (j == 1 || j == (i * 2) - 1)
               {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
               }
            else
                printf(" ");
              
        }

        printf("\n");
     
    }
}
//for middle
if (position == 3)
{
    
    for (i = n/2; i <= n; i += 2)  {
          printf("                                                 ");
          
          for (j = 1; j < n-i; j += 2)
            printf(" ");
          

        for (j = 1; j <= i; j++) {
            if (j == 1 || j == i)
                {
                             // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        for (j = 1; j <= n-i; j++)
            printf(" ");
          

        for (j = 1; j <= i; j++) {
            if (j == 1 || j == i)
                {
                             // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        printf("\n");
     
    }
     for (i = n; i >= 1; i--){
printf("                                                 ");
          for (j = i; j < n; j++)
            printf(" ");
          

        for (j = 1; j <= (i * 2) - 1; j++) {
            if (j == 1 || j == (i * 2) - 1)
                {
                             // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
              
                printf("\033[0m");
                }
            else
                printf(" ");
              
        }

        printf("\n");
     
     }
}
}
