#include "Data_header.h"
// Functions to input the size,symbl,colour
void filled_hexagon(int row,int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
    
// for left
if (position == 1)
    {
        
        for(i = 1; i <= row; i++) 
        {
           for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
            }
             for(int k=1;k<=2*i+1;k++)
            {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
            }
            printf("\n");
        }
         for(int i=row-1;i>=1;i--)
{
    for(int j=1;j<=row-i;j++)
    {
          printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
    }
    for(int k=1;k<=2*i+1;k++)
    {
          printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");

    }

        printf("\n");   
          
}     
             
}
    
    
// for right
if (position == 2)
    {
         
        for(i = 1; i <= row; i++) {
             printf("                                                                                                   ");
        for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
            }
            for(int k=1;k<=2*i+1;k++)
            {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
            }
            printf("\n");
        }
               for(int i=row-1;i>=1;i--)
{
      printf("                                                                                                   ");
    for(int j=1;j<=row-i;j++)
    {
          printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
    }
    for(int k=1;k<=2*i+1;k++)
    {
          printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");

    }

        printf("\n");  
                   
}

    }
    //for middle
    if (position == 3)
    {
         
        for(i = 1; i <= row; i++) {
printf("                                                 ");
         for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
            }
             for(int k=1;k<=2*i+1;k++)
            {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
            }
            printf("\n");
        }
               for(int i=row-1;i>=1;i--)
{
    printf("                                                 ");
    for(int j=1;j<=row-i;j++)
    {
          printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
    }
    for(int k=1;k<=2*i+1;k++)
    {
          printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");

    }

        printf("\n"); 
                    
}

    }
}

    
// Functions to input the size,symbl,colour
void hollow_hexagon(int row, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
         
    for (int i = 1; i <= row; i++) {
       for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
            }
           for(int k=1;k<=2*i+1;k++)
    {
        if(i==1 || k==1 || k==2*i+1)
        {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
            }
            else
            {
              printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");  
            }
            }
        printf("\n");  
                   
}
for(int i=row-1;i>=1;i--)
{
    for(int j=1;j<=row-i;j++)
    {
        printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
        
         printf("\033[0m");  
    }
    for(int k=1;k<=2*i+1;k++)
    {
        if( i==row || k==1 || k==2*i+1)
        {
            printf("\033[0;%d;40m", colour); 
        printf("%c",symbol);//printing colour
       
         printf("\033[0m");
    }
    else
    {
         printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
        
        printf("\033[0m");  
    } 
    }
    printf("\n");
       
}

}
    

// for right
if (position == 2)
{
     
    for (int i = 1; i <= row; i++) {
                     printf("                                                                                                   ");
       for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
            }
            for(int k=1;k<=2*i+1;k++)
    {
        if(i==1 || k==1 || k==2*i+1)
        {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
            }
            else
            {
              printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");  
            }
            }
        printf("\n");  
                   
}
for(int i=row-1;i>=1;i--)
{
     printf("                                                                                                   ");
    for(int j=1;j<=row-i;j++)
    {
        printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
        
         printf("\033[0m");  
    }
    for(int k=1;k<=2*i+1;k++)
    {
        if( i==row || k==1 || k==2*i+1)
        {
            printf("\033[0;%d;40m", colour); 
        printf("%c",symbol);//printing colour
       
         printf("\033[0m");
    }
    else
    {
         printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
        
        printf("\033[0m");  
    } 
    }
    printf("\n");
       
}

}
//for middle
if (position == 3)
{
     
    for (int i = 1; i <= row; i++) {
          printf("                                                 ");
         for(int j=1;j<=row-i;j++)
        {

                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");
            }
            for(int k=1;k<=2*i+1;k++)
    {
        if(i==1 || k==1 || k==2*i+1)
        {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
               
                printf("\033[0m");
            }
            else
            {
              printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                
                printf("\033[0m");  
            }
            }
        printf("\n");  
                   
}
for(int i=row-1;i>=1;i--)
{
     printf("                                                 ");
    for(int j=1;j<=row-i;j++)
    {
        printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
        
         printf("\033[0m");  
    }
    for(int k=1;k<=2*i+1;k++)
    {
        if( i==row || k==1 || k==2*i+1)
        {
            printf("\033[0;%d;40m", colour); 
        printf("%c",symbol);//printing colour
       
         printf("\033[0m");
    }
    else
    {
         printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
        
        printf("\033[0m");  
    } 
    }
    printf("\n");
       
}

}
}
