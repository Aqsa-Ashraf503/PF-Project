void filled_squareT(int row, int colour, char symbol,int position);
void hollow_squareT(int row, int colour, char symbol,int position);
void filled_rectangleT(int row, int colour, char symbol,int position);
void hollow_rectangleT(int row, int colour, char symbol,int position);
void filled_hexagonT(int row,int colour, char symbol,int position);
void hollow_hexagonT(int row, int colour, char symbol,int position);
void hollow_pentagonT(int row, int colour, char symbol,int position);