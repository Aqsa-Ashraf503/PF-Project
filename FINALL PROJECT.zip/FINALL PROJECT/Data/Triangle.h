void inverse_right_triangle_hollow(int row, int colour, char symbol, int position);
void inverse_right_triangle_filled(int row, int colour, char symbol, int position);
void right_triangle_hollow(int row, int colour, char symbol, int position);
void right_triangle_filled(int row, int colour, char symbol, int position);
void filled_mirrored_triangle(int row, int colour, char symbol,int position);
void hollow_mirrored_triangle(int row, int colour, char symbol,int position);
void filled_inverted_mirrored_triangle(int row, int colour, char symbol,int position);
void hollow_inverted_mirrored_triangle(int row, int colour, char symbol,int position);