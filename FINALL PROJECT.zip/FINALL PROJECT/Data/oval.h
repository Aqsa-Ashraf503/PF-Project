void filled_oval(int row, int colour, char symbol, int position);
void hollow_oval(int row, int colour, char symbol, int position);