void filled_square(int row, int colour, char symbol,int position);
void hollow_square(int row, int colour, char symbol,int position);