void filled_kite(int row, int colour, char symbol,int position);
void hollow_kite(int row, int colour, char symbol,int position);