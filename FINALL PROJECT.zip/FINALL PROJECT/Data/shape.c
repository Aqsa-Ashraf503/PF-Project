#include "Data_header.h"
// Functions to input the size,symbl,colour
void filled_squareT(int row, int colour, char symbol,int position)
{   
  FILE *done = fopen("square.txt", "w");
// intializing the variables
    int i;
    int j;
    
// for left
if (position == 1)
    {
        for(i = 1; i <= row; i++) 
        {
           for(int j=1;j<=row;j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
         
        }
        printf("\n");  
            fprintf(done, "\n");      
}

    }
// for right
if (position == 2)
    {

        for(i = 1; i <= row; i++) {
 printf("                                                                                                   ");
         for(int j=1;j<=row;j++)
        {
            
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
          
        }
        printf("\n"); 
          fprintf(done, "\n");          
}

    }
    //for middle
    if (position == 3)
    {
        
        for(int i = 1; i <= row; i++) {
        printf("                                                 ");
         for(int j=1;j<=row;j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
          
        }

        printf("\n"); 
          fprintf(done, "\n");          
}
fclose(done);
    }
}

// Functions to input the size,symbl,colour
void hollow_squareT(int row, int colour, char symbol,int position)
{   
   FILE *done = fopen("square.txt", "w");
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
    for (int i = 1; i <= row; i++) {
        for(int j=1;j<=row;j++)
        {
            if(i==1 ||j==1 ||i==row || j==row)
       {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                  fprintf(done, " ");
                printf("\033[0m");
            }
        }
        printf("\n");  
          fprintf(done, "\n");         
}

}

// for right
if (position == 2)
{
    
    for (int i = 1; i <= row; i++) {
      printf("                                                                                                   ");               
        for(int j=1;j<=row;j++)
        {
           if(i==1 ||j==1 ||i==row || j==row)
      {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                  fprintf(done, " ");
                printf("\033[0m");
            }
        }
        printf("\n");
          fprintf(done, "\n");           
}

}
//for middle
if (position == 3)
{
     
    
    for (int i = 1; i <= row; i++) {
        printf("                                                 ");
          for(int j=1;j<=row;j++)
        {
            if(i==1 ||j==1 ||i==row || j==row)
         {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                  fprintf(done, " ");
                printf("\033[0m");
            }
        }

        printf("\n");  
          fprintf(done, "\n");         
}
fclose(done);
}
}

// Functions to input the size,symbl,colour
void filled_rectangleT(int row, int colour, char symbol,int position)
{   
     FILE *done = fopen("rectangle.txt", "w");
// intializing the variables
    int i;
    int j;
    int col=row;

    
// for left
if (position == 1)
    {
      
        for(i = 0; i < row; i++)
        {
           for(j = 0; j < col; j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
         
        }
        printf("\n"); 
         fprintf(done, "\n");         
}

    }
// for right
if (position == 2)
    {
         
        for(i = 0; i < row; i++) {
             printf("                                                                                                   ");
          for(j = 0; j < col; j++)
        {
            
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
          
        }
        printf("\n");   
         fprintf(done, "\n");       
}

    }
    //for middle
    if (position == 3)
    {
         
        for(i = 0; i < row; i++)
         {
printf("                                                 ");
         for(j = 0; j < col; j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
          
        }
        printf("\n");  
         fprintf(done, "\n");        
}
fclose(done);
    }
}
    
// Functions to input the size,symbl,colour
void hollow_rectangleT(int row, int colour, char symbol,int position)
{
      FILE *done = fopen("rectangle.txt", "w");
// intializing the variables
    int i;
    int j;
    int col=row;
// for left
if (position == 1)
    {
     
    for (int i = 0 ; i < row ; i++) 
    {
        for(int j=0 ; j < col ; j++)

        {
            if(i==0 || i==row-1 || j==0 || j==col-1)
       
        {// printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");}
            
            else{
            
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            
        }
        printf("\n");
         fprintf(done, "\n");
                

    }

}

// for right
if (position == 2)
{
     
    for (int i = 0; i < row; i++) {
                     printf("                                                                                                   ");
         for(int j=0 ; j < col ; j++)
        {
           if(i==0 || i==row-1 || j==0 || j==col-1)
      {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
          
        }
   printf("\n");
    fprintf(done, "\n");
                  
}

}
//for middle
if (position == 3)
{
     
    for (int i = 0; i < row; i++) {
          printf("                                                 ");
          for(int j=0; j < col ; j++)
        {
           if(i==0 || i==row-1 || j==0 || j==col-1)
         {
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            
        }

           printf("\n");      
            fprintf(done, "\n");    
}
fclose(done);
}
}

// Functions to input the size,symbl,colour
void filled_hexagonT(int row,int colour, char symbol,int position)
{   
     FILE *done = fopen("hexagon.text", "w");
// intializing the variables
    int i;
    int j;
    
// for left
if (position == 1)
    {
         FILE *done = fopen("hexagon.text", "w");
        for(i = 1; i <= row; i++) 
        {
           for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
             for(int k=1;k<=2*i+1;k++)
            {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
         
        
        printf("\n");   
        fprintf(done, "\n");  
        }
        for(int i=row-1;i>=1;i--)
{
    for(int j=1;j<=row-i;j++)
    {
         printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");

    }
    for(int k=1;k<=2*i+1;k++)
    {
         // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m"); 
    }
    printf("\n");
    fprintf(done,"\n");
}
           
}
    
// for right
if (position == 2)
    {
         
        for(i = 1; i <= row; i++) {
             printf("                                                                                                   ");
        for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for(int k=1;k<=2*i+1;k++)
            {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
        printf("\n");  
        fprintf(done, "\n");           
}
  for(int i=row-1;i>=1;i--)
{   printf("                                                                                                   ");

    for(int j=1;j<=row-i;j++)
    {
         printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");

    }
    for(int k=1;k<=2*i+1;k++)
    {
         // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m"); 
    }
    printf("\n");
    fprintf(done,"\n");
}

    }
    //for middle
    if (position == 3)
    {
         
        for(i = 1; i <= row; i++) {
printf("                                                 ");
         for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
             for(int k=1;k<=2*i+1;k++)
            {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
        printf("\n"); 
        fprintf(done, "\n");            
}
  for(int i=row-1;i>=1;i--)
{
    printf("                                                 ");
    for(int j=1;j<=row-i;j++)
    {
         printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");

    }
    for(int k=1;k<=2*i+1;k++)
    {
         // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m"); 
    }
    printf("\n");
    fprintf(done,"\n");
}
fclose(done);
    }
}

    
// Functions to input the size,symbl,colour
void hollow_hexagonT(int row, int colour, char symbol,int position)
{   
     FILE *done = fopen("hexagon.text", "w");
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
          FILE *done = fopen("hexagon.text", "w");
    for (int i = 1; i <= row; i++) {
       for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
           for(int k=1;k<=2*i+1;k++)
    {
        if(i==1 || k==1 || k==2*i+1)
        {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
              printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");  
            }
            }
        printf("\n");  
        fprintf(done, "\n");           
}
for(int i=row-1;i>=1;i--)
{
    for(int j=1;j<=row-i;j++)
    {
        printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
         fprintf(done, " ");
         printf("\033[0m");  
    }
    for(int k=1;k<=2*i+1;k++)
    {
        if( i==row || k==1 || k==2*i+1)
        {
            printf("\033[0;%d;40m", colour); 
        printf("%c",symbol);//printing colour
          fprintf(done, "%c", symbol);
         printf("\033[0m");
    }
    else
    {
         printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
         fprintf(done, " ");
        printf("\033[0m");  
    } 
    }
    printf("\n");
    fprintf(done, "\n");   
}

}
    

// for right
if (position == 2)
{
    for (int i = 1; i <= row; i++) {
                     printf("                                                                                                   ");
       for(int j=1;j<=row-i;j++)
        {
                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for(int k=1;k<=2*i+1;k++)
    {
        if(i==1 || k==1 || k==2*i+1)
        {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
              printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");  
            }
            }
        printf("\n");  
        fprintf(done, "\n");           
}
for(int i=row-1;i>=1;i--)
{
     printf("                                                                                                   ");
    for(int j=1;j<=row-i;j++)
    {
        printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
         fprintf(done, " ");
         printf("\033[0m");  
    }
    for(int k=1;k<=2*i+1;k++)
    {
        if( i==row || k==1 || k==2*i+1)
        {
            printf("\033[0;%d;40m", colour); 
        printf("%c",symbol);//printing colour
          fprintf(done, "%c", symbol);
         printf("\033[0m");
    }
    else
    {
         printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
         fprintf(done, " ");
        printf("\033[0m");  
    } 
    }
    printf("\n");
    fprintf(done, "\n");   
}

}
//for middle
if (position == 3)
{
    
    for (int i = 1; i <= row; i++) {
          printf("                                                 ");
         for(int j=1;j<=row-i;j++)
        {

                printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for(int k=1;k<=2*i+1;k++)
    {
        if(i==1 || k==1 || k==2*i+1)
        {
                 // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                  fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            else
            {
              printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                 fprintf(done, " ");
                printf("\033[0m");  
            }
            }
        printf("\n");  
        fprintf(done, "\n");           
}
for(int i=row-1;i>=1;i--)
{
     printf("                                                 ");
    for(int j=1;j<=row-i;j++)
    {
        printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
         fprintf(done, " ");
         printf("\033[0m");  
    }
    for(int k=1;k<=2*i+1;k++)
    {
        if( i==row || k==1 || k==2*i+1)
        {
            printf("\033[0;%d;40m", colour); 
        printf("%c",symbol);//printing colour
          fprintf(done, "%c", symbol);
         printf("\033[0m");
    }
    else
    {
         printf("\033[0;%d;40m", colour);
        printf(" ");//printing space
         fprintf(done, " ");
        printf("\033[0m");  
    } 
    }
    printf("\n");
    fprintf(done, "\n");   
}
fclose(done);
}
}


// Functions to input the size,symbl,colour
void filled_pentagonT(int row, int colour, char symbol, int position)
{  FILE *done = fopen("pentagon", "w");
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
        
        for (int i = 0; i < row; i++)
        {

            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            printf("\n");
            fprintf(done, "\n"); 
        }

        for (int i = row; i >= 2; i--)
        {

            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
     
    }
    // for right
    if (position == 2)
    {
      
        for (i = 0; i < row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
            }

            printf("\n");
            fprintf(done, "\n"); 
        }

        for (int i = row; i >= 2; i--)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
            }

            printf("\n");
            fprintf(done, "\n"); 
        }
    
    }

    // for middle
    if (position == 3)
    {
        
        for (i = 0; i < row; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
            }

            printf("\n");
            fprintf(done, "\n"); 
        }

        for (int i = row; i >= 2; i--)
        {
            printf("                                                 ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                 fprintf(done, "%c", symbol);
                printf("\033[0m");
            }

            printf("\n");
            fprintf(done, "\n"); 
        }
         fclose(done);
    }
}

// Functions to input the size,symbl,colour
void hollow_pentagonT(int row, int colour, char symbol, int position)
{
      FILE *done = fopen("pentagon", "w");
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
      
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                if (k == 0 || k == (i * 2 - 1) - 1)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                     fprintf(done, "%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  "); // printing space
                     fprintf(done, " ");
                    printf("\033[0m");
                }
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
        for (int i = row; i >= 2; i--)
        {
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                if (k == 0 || k == (i * 2 - 1) - 1 || i == 2)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                     fprintf(done, "%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  "); // printing space
                     fprintf(done, " ");
                    printf("\033[0m");
                }
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
     
    }

    // for right
    if (position == 2)
    {
   
        for (int i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                if (k == 0 || k == (i * 2 - 1) - 1)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                     fprintf(done, "%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  "); // printing space
                     fprintf(done, " ");
                    printf("\033[0m");
                }
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
        for (int i = row; i >= 2; i--)
        {
            printf("                                                                                                   ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                if (k == 0 || k == (i * 2 - 1) - 1 || i == 2)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                     fprintf(done, "%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  "); // printing space
                     fprintf(done, " ");
                    printf("\033[0m");
                }
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
     
    }
    // for middle
    if (position == 3)
    {
   
        for (int i = 1; i <= row; i++)
        {
            printf("                                                 ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                if (k == 0 || k == (i * 2 - 1) - 1)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                     fprintf(done, "%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  "); // printing space
                     fprintf(done, " ");
                    printf("\033[0m");

                }
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
        for (int i = row; i >= 2; i--)
        {
            printf("                                                 ");
            for (int j = 0; j < row - i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("  "); // printing space
                 fprintf(done, " ");
                printf("\033[0m");
            }
            for (int k = 0; k < i * 2 - 1; k++)
            {
                if (k == 0 || k == (i * 2 - 1) - 1 || i == 2)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                     fprintf(done, "%c", symbol);
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf("  "); // printing space
                     fprintf(done, " ");
                    printf("\033[0m");
                }
            }
            printf("\n");
            fprintf(done, "\n"); 
        }
        fclose(done);
    }
}







    



