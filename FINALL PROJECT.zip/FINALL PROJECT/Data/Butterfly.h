void filled_butterfly(int row, int colour, char symbol,int position);
void hollow_butterfly(int row, int colour, char symbol,int position);