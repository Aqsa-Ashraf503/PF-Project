#include "Data_header.h"
void hut(int n, int colour, char symbol,int position)
{   
// intializing the variables
    int i,j,t;
// for left
if (position == 1)
    {

     if(n%2==0)
    n++;
    for(i=0;i<=n-n/3;i++)
    {
        for(j=0;j<n;j++)
        {
            t=2*n/5;
            if(t%2!=0)
            t--;
            if(i==n/5 || i==n-n/3 || (j==n-1 && i>=n/5) || (j>=n/5 && j < n-n/5 && i==0) || (j==0 && i>=n/5) || (j==t && i>n/5)|| (i<=n/5 && (i +j==n/5 || j-i==n/5)) || (j-i==n-n/5))
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" %c", symbol);
          
                printf("\033[0m");
            }
            else if(i==n/5+n/7 && (j>=n/7 && j<=t-n/7)) 
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" _", symbol);
                
                printf("\033[0m");
            }
            else if(i>=n/5+n/7 && (j==n/7 || j==t-n/7)) 
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" '", symbol);
        
                printf("\033[0m");
            }
            else
            printf("  ");
          
        }
        printf("\n");
    
    }
}

// for right
if (position == 2)
{
   
    if(n%2==0)
    n++;
     for(i=0;i<=n-n/3;i++){
                     printf("                                                                                                   ");
        for(j=0;j<n;j++)
        {
            t=2*n/5;
            if(t%2!=0)
            t--;
            if(i==n/5 || i==n-n/3 || (j==n-1 && i>=n/5) || (j>=n/5 && j < n-n/5 && i==0) || (j==0 && i>=n/5) || (j==t && i>n/5)|| (i<=n/5 && (i +j==n/5 || j-i==n/5)) || (j-i==n-n/5))
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" %c", symbol);
          
                printf("\033[0m");
            }
            else if(i==n/5+n/7 && (j>=n/7 && j<=t-n/7)) 
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" _", symbol);
          
                printf("\033[0m");
            }
            else if(i>=n/5+n/7 && (j==n/7 || j==t-n/7)) 
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" '", symbol);
        
                printf("\033[0m");
            }
            else
            printf("  ");
          
        }
        printf("\n");
    
}
}
//for middle
if (position == 3)
{
   
    if(n%2==0)
    n++;
    for(i=0;i<=n-n/3;i++) {
          printf("                                                 ");
          for(j=0;j<n;j++)
        {
            t=2*n/5;
            if(t%2!=0)
            t--;
            if(i==n/5 || i==n-n/3 || (j==n-1 && i>=n/5) || (j>=n/5 && j < n-n/5 && i==0) || (j==0 && i>=n/5) || (j==t && i>n/5)|| (i<=n/5 && (i +j==n/5 || j-i==n/5)) || (j-i==n-n/5))
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" %c", symbol);
          
                printf("\033[0m");
            }
            else if(i==n/5+n/7 && (j>=n/7 && j<=t-n/7)) 
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" _", symbol);
                
                printf("\033[0m");
            }
            else if(i>=n/5+n/7 && (j==n/7 || j==t-n/7)) 
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf(" '", symbol);
        
                printf("\033[0m");
            }
            else
            printf("  ");
          
        }
        printf("\n");  
       
}
}
}



