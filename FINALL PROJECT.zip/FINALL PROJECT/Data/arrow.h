void down_arrow(int row, int colour, char symbol,int position);
void left_arrow(int row, int colour, char symbol,int position);
void right_arrow(int row, int colour, char symbol,int position);
void up_arrow(int row, int colour, char symbol,int position);