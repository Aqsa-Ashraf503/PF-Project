#include "Data_header.h"

// Functions to input the size,symbl,colour
void minar_e_pakistan(int row, int colour, char symbol, int position)
{
    // intializing the variables

    float n = row, i, j, q, w;

    q = tan(M_PI * 0.4);

    w = tan(M_PI * 0.2);

    // for left
    if (position == 1)
    {
     
        for (j = ceil(n * q); j >= 0; j--)
        {

            for (i = -ceil(0.55 * n * q / w - n); i < ceil(0.55 * n * q / w - n); i++)
            {

                if ((j <= 0.55 * n * q && j >= (i + n) * w && j >= (n - i) * w) || (j >= (i + n) * w && j <= (i + n) * q && j <= (n - i) * q) || (j <= (n - i) * q && j >= (n - i) * w && j <= (i + n) * q))
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" ");
                  // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
            
         
        }
    }
    // for right
    if (position == 2)
    {
     
        for (j = ceil(n * q); j >= 0; j--)
        {
            printf("                                                                                                   ");
            for (i = -ceil(0.55 * n * q / w - n); i < ceil(0.55 * n * q / w - n); i++)
            {

                if ((j <= 0.55 * n * q && j >= (i + n) * w && j >= (n - i) * w) || (j >= (i + n) * w && j <= (i + n) * q && j <= (n - i) * q) || (j <= (n - i) * q && j >= (n - i) * w && j <= (i + n) * q))
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" ");
                  // printing space
                    printf("\033[0m");
                }
            }

            printf("\n");
            
         
        }
    }
    // for middle
    if (position == 3)
    {
     
        for (j = ceil(n * q); j >= 0; j--)
        {
            printf("                                                 ");
            for (i = -ceil(0.55 * n * q / w - n); i < ceil(0.55 * n * q / w - n); i++)
            {

                if ((j <= 0.55 * n * q && j >= (i + n) * w && j >= (n - i) * w) || (j >= (i + n) * w && j <= (i + n) * q && j <= (n - i) * q) || (j <= (n - i) * q && j >= (n - i) * w && j <= (i + n) * q))
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" ");
                    
                    ; // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
            
         
        }
    }
}
