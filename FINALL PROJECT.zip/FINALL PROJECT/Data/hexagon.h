void filled_hexagon(int row,int colour, char symbol,int position);
void hollow_hexagon(int row,int colour, char symbol,int position);