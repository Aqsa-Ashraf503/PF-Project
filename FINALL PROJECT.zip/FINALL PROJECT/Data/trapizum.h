void filled_trapizum(int row, int colour, char symbol,int position);
void hollow_trapizum(int row, int colour, char symbol,int position);
void reverse_filled_trapizum(int row, int colour, char symbol,int position);
void reverse_hollow_trapizum(int row, int colour, char symbol,int position);