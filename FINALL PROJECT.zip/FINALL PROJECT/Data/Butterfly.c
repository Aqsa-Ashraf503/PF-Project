#include "Data_header.h"

void filled_butterfly(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
        
        for (i = 1; i <= row; i++)
        {
            for (int j = 1; j <= i; j++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            printf("\n");
           
            
        }
        for (i = row - 1; i >= 1; i--)
        {

            for (int j = 1; j <= i; j++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            printf("\n");
           
        }
       
    }
    // for right
    if (position == 2)
    {
        
        for (i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= i; j++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            printf("\n");
           
        }
        for (i = row - 1; i >= 1; i--)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= i; j++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        
        for (i = 1; i <= row; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= i; j++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            printf("\n");
           
        }
        for (i = row - 1; i >= 1; i--)
        {
            printf("                                                 ");
            for (int j = 1; j <= i; j++)
            {

                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
          
                printf("\033[0m");
            }
            printf("\n");
           
        }
       
    }
}

// Functions to input the size,symbl,colour
void hollow_butterfly(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        
        for (i = 1; i <= row; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
        for (i = row - 1; i >= 1; i--)
        {
            for (int j = 1; j <= i; j++)
            {

                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }

    // for right
    if (position == 2)
    {
        
        for (int i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
        for (i = row - 1; i >= 1; i--)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= i; j++)
            {

                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
    // for middle
    if (position == 3)
    {
        
        for (int i = 1; i <= row; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
        for (i = row - 1; i >= 1; i--)
        {
            printf("                                                 ");
            for (int j = 1; j <= i; j++)
            {

                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            for (int k = 1; k <= (row - i) * 2; k++)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space
              
                printf("\033[0m");
            }
            for (int j = 1; j <= i; j++)
            {
                if (j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
              
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                  
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
       
    }
}
