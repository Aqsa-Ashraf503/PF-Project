void filled_rectangle(int row, int colour, char symbol,int position);
void hollow_rectangle(int row, int colour, char symbol,int position);