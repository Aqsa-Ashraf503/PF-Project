#include "Data_header.h"
// Functions to input the size,symbl,colour
void filled_reverse_pyramid(int row, int colour, char symbol, int position)
{
    if(position==1)
    {
       
         for ( int i = row; i >=1; i--)
    {
        for (int j=row-1; j>=i; j--)
        {
            printf(" ");
            
        }
        for (int k=1; k<=i; k++)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                
                printf("\033[0m");
        }
        printf("\n");
        
        }
         
    }
    if (position==2)
    {
       
         for ( int i = row; i >=1; i--)
    {
        printf("                                                                                                ");
        for (int j=row-1; j>=i; j--)
        {
            printf(" ");
            
        }
        for (int k=1; k<=i; k++)
        {
                 printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                
                printf("\033[0m");
        }
        printf("\n");
        
        }
         
    }
    if(position==3)
    {
       
         for ( int i = row; i >=1; i--)
    {
        printf("                                                  ");
        for (int j=row-1; j>=i; j--)
        {
            printf(" ");
            
        }
        for (int k=1; k<=i; k++)
        {
                 printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                
                printf("\033[0m");
        }
        printf("\n");
        
        }
         
    }
}
void hollow_reverse_pyramid(int row, int colour, char symbol, int position)
{
    if(position==1)
    {
       
for ( int i = row; i >=1; i--)
    {
        for (int j=row-1; j>=i; j--)
        {
            printf(" ");
            
        }
        for (int k=1; k<=i; k++)
        {
            if(k==1||i==k||i==row)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf("  ");
                
                printf("\033[0m");
            }
        }
        printf("\n");
        
        }
         
    }
    if (position==2)
    {
       
        for ( int i = row; i >=1; i--)
    {
        printf("                                                                                                    ");
        for (int j=row-1; j>=i; j--)
        {
            printf(" ");
            
        }
        for (int k=1; k<=i; k++)
        {
            if(k==1||i==k||i==row)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf("  ");
                
                printf("\033[0m");
            }
        }
        printf("\n");
        
        }
         
    }
    if (position==3)
    {
       
        for ( int i = row; i >=1; i--)
    {
        printf("                                                   ");
        for (int j=row-1; j>=i; j--)
        {
            printf(" ");
            
        }
        for (int k=1; k<=i; k++)
        {
            if(k==1||i==k||i==row)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                
                printf("\033[0m");
            }
            else
            {
                printf("\033[0;%d;40m", colour);
                printf("  ");
                
                printf("\033[0m");
            }
        }
        printf("\n");
        
        }
         
    }
}




void filled_pyramid(int row, int colour, char symbol, int position)
{
    int i, j;

    if (position == 1)
    {
       
        for (i = 1; i <= row ; i++)
        {
            for (j = 1; j <= row- i; j++)
            {
                printf(" ");
                
            }
            for (j = 1; j <= 2 * i - 1; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");
            }
            printf("\n");
            
        }
         
    }
    else if (position == 2)
    {
       
        for (i = 1; i <= row; i++)
        {
            printf("                                             ");
            for (j = 1; j <= row - i; j++)
            {
                printf(" ");
                
            }
            for (j = 1; j <= 2 * i - 1; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");
            }
            printf("\n");
            
        }
         
    }
    else if (position == 3)
    {
       
        for (i = 1; i <= row; i++)
        {
            printf("                               ");
            for (j = 1; j <= row - i; j++)
            {
                printf(" ");
                
            }
            for (j = 1; j <= 2 * i - 1; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                
                printf("\033[0m");
            }
            printf("\n");
            
        }
         
    }
}

void hollow_pyramid(int row, int colour, char symbol, int position)
{
    int i, j;

    if (position == 1)
    {
       
        for (i = 1; i <= row; i++)
        {
            for (j = 1; j <= row - i; j++)
            {
                printf(" ");
                
            }
            for (j = 1; j <= 2 * i - 1; j++)
            {
                if (j == 1 || j == 2 * i - 1 || i == row)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                    
                }
            }
            printf("\n");
            
        }
         
    }
    else if (position == 2)
    {
       
        for (i = 1; i <= row; i++)
        {
            printf("                                             ");
            for (j = 1; j <= row - i; j++)
            {
                printf(" ");
                
            }
            for (j = 1; j <= 2 * i - 1; j++)
            {
                if (j == 1 || j == 2 * i - 1 || i == row)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                    
                }
            }
            printf("\n");
            
        }
         
    }
    else if (position == 3)
    {
       
        for (i = 1; i <= row; i++)
        {
            printf("                               ");
            for (j = 1; j <= row - i; j++)
            {
                printf(" ");
                
            }
            for (j = 1; j <= 2 * i - 1; j++)
            {
                if (j == 1 || j == 2 * i - 1 || i == row)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                    
                }
            }
            printf("\n");
            
        }
         
    }
}



