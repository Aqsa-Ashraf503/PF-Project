#include "Data_header.h"

// Functions to input the row,symbl,colour
void down_arrow(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
        for (int i = 1; i <= row; i++) {
        for (int j = 1; j <= row * 2 - 1; j++) {
            if (j == row) {
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
    for (int i = 1; i <= row; i++) {
        for (int j = 1; j <= row * 2 - 1; j++) {
            if (j >= i && j <= row * 2 - i) {
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
    }
    // for right
    if (position == 2)
    {
        for (int i = 1; i <= row; i++){
             printf("                                                                                                   ");
        
        for (int j = 1; j <= row * 2 - 1; j++) {
            if (j == row) {
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
    for (int i = 1; i <= row; i++){
        printf("                                                                                                   ");
        for (int j = 1; j <= row * 2 - 1; j++) {
            if (j >= i && j <= row * 2 - i) {
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
    }

    // for middle
    if (position == 3)
    {
  for (int i = 1; i <= row; i++) {
         printf("                                                 ");
            
            for (int j = 1; j <= row * 2 - 1; j++) {
            if (j == row) {
               {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");        
}
    for (int i = 1; i <= row; i++) {
         printf("                                                 ");
          for (int j = 1; j <= row * 2 - 1; j++) {
            if (j >= i && j <= row * 2 - i) {
                {
                    // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
                }
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
}
    
}

// Functions to input the row,symbl,colour
void left_arrow(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int k = row / 2;
    // for left
    if (position == 1)
    {

        for (int i = 1; i <= row / 2; i++)
        {

            for (int j = 1; j <= k; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
        for (int j = 1; j <= row; j++)
        {
            // printing colours
            printf("\033[0;%d;40m", colour);
            printf("%c ", symbol);

            printf("\033[0m");
        }
        printf("\n");

        for (int i = row / 2; i >= 1; i--)
        {

            for (int j = 1; j <= k; j++)
            {
                printf("  ");
            }

            for (int j = 1; j <= i; j++)
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    // for right
    if (position == 2)
    {

        for (int i = 1; i <= row / 2; i++)
        {
            printf("                                                                                                   ");

            for (int j = 1; j <= k; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
        printf("                                                                                                   ");
        for (int j = 1; j <= row; j++)
        {
            // printing colours
            printf("\033[0;%d;40m", colour);
            printf("%c ", symbol);

            printf("\033[0m");
        }
        printf("\n");

        for (int i = row / 2; i >= 1; i--)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= k; j++)
            {
                printf("  ");
            }

            for (int j = 1; j <= i; j++)
            {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }

    // for middle
    if (position == 3)
    {

        for (int i = 1; i <= row / 2; i++)
        {
            printf("                                                 ");

            for (int j = 1; j <= k; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {

                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
        printf("                                                 ");
        for (int j = 1; j <= row; j++)
        {

            printf("\033[0;%d;40m", colour);
            printf("%c ", symbol);

            printf("\033[0m");
        }
        printf("\n");

        for (int i = row / 2; i >= 1; i--)
        {
            printf("                                                 ");
            for (int j = 1; j <= k; j++)
            {
                printf("  ");
            }

            for (int j = 1; j <= i; j++)
            {

                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
}

// Functions to input the row,symbl,colour
void right_arrow(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int n = row / 2;
    if (row % 2 == 0)
    {
        n--;
    }
    // for left
    if (position == 1)
    {

        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n - i + 1; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }

        for (int j = 1; j <= row; j++)
        {
            printf("\033[0;%d;40m", colour);
            printf("%c ", symbol);

            printf("\033[0m");
        }
        printf("\n");

        for (int i = n; i >= 1; i--)
        {
            for (int j = 1; j <= n - i + 1; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    // for right
    if (position == 2)
    {

        for (int i = 1; i <= n; i++)
        {
            printf("                                                                                                   ");

            for (int j = 1; j <= n - i + 1; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
        printf("                                                                                                   ");

        for (int j = 1; j <= row; j++)
        {
            printf("\033[0;%d;40m", colour);
            printf("%c ", symbol);

            printf("\033[0m");
        }
        printf("\n");

        for (int i = n; i >= 1; i--)
        {
            printf("                                                                                                   ");

            for (int j = 1; j <= n - i + 1; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (int i = 1; i <= n; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= n - i + 1; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
        printf("                                                 ");
        for (int j = 1; j <= row; j++)
        {
            printf("\033[0;%d;40m", colour);
            printf("%c ", symbol);

            printf("\033[0m");
        }
        printf("\n");

        for (int i = n; i >= 1; i--)
        {
            printf("                                                 ");
            for (int j = 1; j <= n - i + 1; j++)
            {
                printf("  ");
            }
            for (int j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
}

// Functions to input the row,symbl,colour
void up_arrow(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {

        for (int i = row; i >= 1; i--)
        {
            for (int j = 1; j <= row * 2 - 1; j++)
            {
                if (j >= i && j <= row * 2 - i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("  ");
                }
            }
            printf("\n");
        }

        for (int i = 1; i <= row; i++)
        {
            for (int j = 1; j <= row * 2 - 1; j++)
            {
                if (j == row)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("  ");
                }
            }
            printf("\n");
        }
    }
    // for right
    if (position == 2)
    {

        for (int i = row; i >= 1; i--)
        {
            printf("                                                                                                   ");

            for (int j = 1; j <= row * 2 - 1; j++)
            {
                if (j >= i && j <= row * 2 - i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("  ");
                }
            }
            printf("\n");
        }

        for (int i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= row * 2 - 1; j++)
            {
                if (j == row)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("  ");
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (int i = row; i >= 1; i--)
        {
            printf("                                                 ");

            for (int j = 1; j <= row * 2 - 1; j++)
            {
                if (j >= i && j <= row * 2 - i)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("  ");
                }
            }
            printf("\n");

            for (int i = 1; i <= row; i++)
            {
                printf("                                                 ");
                for (int j = 1; j <= row * 2 - 1; j++)
                {
                    if (j == row)
                    {

                        // printing colours
                        printf("\033[0;%d;40m", colour);
                        printf("%c ", symbol);

                        printf("\033[0m");
                    }
                    else
                    {
                        printf("  ");
                    }
                }
                printf("\n");
            }
        }
    }
}
