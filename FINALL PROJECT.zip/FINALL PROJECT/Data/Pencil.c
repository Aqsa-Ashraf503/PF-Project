#include "Data_header.h"
// Functions to input the size,symbl,colour
void pencil(int row, int colour, char symbol, int position)
{      printf("hellow inside pencil inner");
    // intializing the variables
    int i, j, k;
    // for left
    if (position == 1)
    {
        
        for (i = -row; i <= row; i++)
        {
            k = i;

            for (j = 0; j <= row; j++)
            {
                if (k <= j)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                    
                    printf("\033[0m");
                }
                else
                    printf(" ");
              
            }
            printf("\n");
              
        }
    }
    // for right
    if (position == 2)
    {
        
        for (i = -row; i <= row; i++)
        {
            printf("                                                                                                   ");

            k = i;

            for (j = 0; j <= row; j++)
            {
                if (k <= j)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                    
                    printf("\033[0m");
                }
                else
                    printf(" ");
              
            }
            printf("\n");
              
        }
    }
    // for middle
    if (position == 3)
    {
        
        for (i = -row; i <= row; i++)
        {
            printf("                                                 ");
            k = i;

            for (j = 0; j <= row; j++)
            {
                if (k <= j)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c ", symbol);
                    
                    printf("\033[0m");
                }
                else
                    printf(" ");
              
            }
            printf("\n");
              
        }
    }
}

