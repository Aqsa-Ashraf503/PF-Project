void filled_roundrectangle(int row,int column, int colour, char symbol,int position);
void hollow_roundrectangle(int row,int column, int colour, char symbol,int position);
