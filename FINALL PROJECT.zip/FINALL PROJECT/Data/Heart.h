void filled_heart(int n, int colour, char symbol,int position);
void hollow_heart(int n, int colour, char symbol,int position);