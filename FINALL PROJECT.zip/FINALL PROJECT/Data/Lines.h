void horizontal_line(int row, int colour, char symbol,int position);
void vertical_line(int row, int colour, char symbol,int position);
void print_character1(int row, int colour, char symbol,int position, char choice);