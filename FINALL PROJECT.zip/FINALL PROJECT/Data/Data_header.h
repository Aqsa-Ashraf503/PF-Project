#ifndef DATA_HEADER_FILE
#define DATA_HEADER_FILE
#define ENTER 13
#define TAB 9
#define BCKSPC 8
#define M_PI 3.14159265358979323846
#include "Alphabets.h"
#include "hexagon.h"
#include "paralellogram.h"
#include "square.h"
#include "trapizum.h"
#include "butterfly.h"
#include "round_rectangle.h"
#include "fish.h"
#include "pentagon.h"
#include "rectangle.h"
#include "lines.h"
#include "number.h"
#include "Triangle.h"
#include "circle.h"
#include "oval.h"
#include "plus.h"
#include "pencil.h"
#include "hut.h"
#include "minar_e_pakistan.h"
#include "heart.h"
#include "Diamond.h"
#include "pyramid.h"
#include "arrow.h"
#include "shape.h"
#include "Kite.h"

#include <stdio.h>
#include  <string.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <math.h>
#include <conio.h>
#include <windows.h>
#include<stddef.h>


#endif