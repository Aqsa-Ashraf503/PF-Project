#include <stdio.h>
#include <conio.h>
#include <windows.h>

void inverse_right_triangle_hollow(int row, int colour, char symbol, int position)
{
    int i, j;

    if (position == 1)
    {

        for (i = row; i >= 1; i--)
        {
            for (j = 1; j <= i; j++)
            {
                if (j == 1 || j == i || i == row)
                {
                    printf("\033[0;%d;40m%c", colour, symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
    else if (position == 2)
    {

        for (i = row; i >= 1; i--)
        {
            printf("                                             ");
            for (j = 1; j <= i; j++)
            {
                if (j == 1 || j == i || i == row)
                {
                    printf("\033[0;%d;40m%c", colour, symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
    else if (position == 3)
    {

        for (i = row; i >= 1; i--)
        {
            printf("                               ");
            for (j = 1; j <= i; j++)
            {
                if (j == 1 || j == i || i == row)
                {
                    printf("\033[0;%d;40m%c", colour, symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
}

void inverse_right_triangle_filled(int row, int colour, char symbol, int position)
{
    int i, j;

    if (position == 1)
    {

        for (i = row; i >= 1; i--)
        {
            for (j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m%c", colour, symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    else if (position == 2)
    {

        for (i = row; i >= 1; i--)
        {
            printf("                                             ");
            for (j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m%c", colour, symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    else if (position == 3)
    {

        for (i = row; i >= 1; i--)
        {
            printf("                               ");
            for (j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m%c", colour, symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
}

void right_triangle_hollow(int row, int colour, char symbol, int position)
{
    int i, j;

    if (position == 1)
    {

        for (i = 1; i <= row; i++)
        {
            for (j = 1; j <= i; j++)
            {
                if (j == 1 || j == i || i == row)
                {
                    printf("\033[0;%d;40m%c", colour, symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
    else if (position == 2)
    {

        for (i = 1; i <= row; i++)
        {
            printf("                                             ");
            for (j = 1; j <= i; j++)
            {
                if (j == 1 || j == i || i == row)
                {
                    printf("\033[0;%d;40m%c", colour, symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
    else if (position == 3)
    {

        for (i = 1; i <= row; i++)
        {
            printf("                               ");
            for (j = 1; j <= i; j++)
            {
                if (j == 1 || j == i || i == row)
                {
                    printf("\033[0;%d;40m%c", colour, symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf(" ");
                }
            }
            printf("\n");
        }
    }
}

void right_triangle_filled(int row, int colour, char symbol, int position)
{
    int i, j;

    if (position == 1)
    {

        for (i = 1; i <= row; i++)
        {
            for (j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m%c", colour, symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    else if (position == 2)
    {

        for (i = 1; i <= row; i++)
        {
            printf("                                             ");
            for (j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m%c", colour, symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
    else if (position == 3)
    {

        for (i = 1; i <= row; i++)
        {
            printf("                               ");
            for (j = 1; j <= i; j++)
            {
                printf("\033[0;%d;40m%c", colour, symbol);

                printf("\033[0m");
            }
            printf("\n");
        }
    }
}

void filled_mirrored_triangle(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {

        for (i = 0; i < row; i++)
        {
            for (j = 0; j < row; j++)
            {
                if (j < row - i - 1)
                {

                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else

                // printing colours

                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for right
    if (position == 2)
    {

        for (i = 0; i < row; i++)
        {
            printf("                                                                                                   ");

            for (j = 0; j < row; j++)
            {
                if (j < row - i - 1)
                {

                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else

                // printing colours

                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (i = 0; i < row; i++)
        {
            printf("                                                 ");

            for (j = 0; j < row; j++)
            {
                if (j < row - i - 1)
                {

                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else

                // printing colours

                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
}

// Functions to input the size,symbl,colour
void hollow_mirrored_triangle(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {

        for (i = 1; i <= row; i++)
        {
            for (j = i; j < row; j++)
            {

                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space

                printf("\033[0m");
            }
            for (j = 1; j <= i; j++)
            {
                if (i == row || j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }

    // for right
    if (position == 2)
    {

        for (int i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (j = i; j < row; j++)
            {

                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space

                printf("\033[0m");
            }
            for (j = 1; j <= i; j++)
            {
                if (i == row || j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (int i = 1; i <= row; i++)
        {
            printf("                                                 ");
            for (j = i; j < row; j++)
            {

                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space

                printf("\033[0m");
            }
            for (j = 1; j <= i; j++)
            {
                if (i == row || j == 1 || j == i)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
}

void filled_inverted_mirrored_triangle(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {

        for (i = 0; i < row; i++)
        {
            for (j = 0; j < row; j++)
            {
                if (j < i)
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for right
    if (position == 2)
    {

        for (i = 0; i < row; i++)
        {
            printf("                                                                                                   ");
            for (j = 0; j < row; j++)
            {
                if (j < i)
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (i = 0; i < row; i++)
        {
            printf("                                                 ");
            for (j = 0; j < row; j++)
            {
                if (j < i)
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
}

// Functions to input the size,symbl,colour
void hollow_inverted_mirrored_triangle(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {

        for (i = row; i > 0; i--)
        {
            for (j = row - i; j > 0; j--)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space

                printf("\033[0m");
            }

            if (i == 1 || i == row)
            {
                for (j = 1; j <= i; j++)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            else
            {
                for (j = 1; j <= i; j++)
                {
                    if (j == 1 || j == i)
                    {
                        // printing colours
                        printf("\033[0;%d;40m", colour);
                        printf("%c", symbol);

                        printf("\033[0m");
                    }
                    else
                    {
                        printf("\033[0;%d;40m", colour);
                        printf(" "); // printing space

                        printf("\033[0m");
                    }
                }
            }
            printf("\n");
        }
    }

    // for right
    if (position == 2)
    {

        for (i = row; i > 0; i--)
        {
            printf("                                                                                                   ");
            for (j = row - i; j > 0; j--)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space

                printf("\033[0m");
            }

            if (i == 1 || i == row)
            {
                for (j = 1; j <= i; j++)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            else
            {
                for (j = 1; j <= i; j++)
                {
                    if (j == 1 || j == i)
                    {
                        // printing colours
                        printf("\033[0;%d;40m", colour);
                        printf("%c", symbol);

                        printf("\033[0m");
                    }
                    else
                    {
                        printf("\033[0;%d;40m", colour);
                        printf(" "); // printing space

                        printf("\033[0m");
                    }
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (i = row; i > 0; i--)
        {
            printf("                                                 ");
            for (j = row - i; j > 0; j--)
            {
                printf("\033[0;%d;40m", colour);
                printf(" "); // printing space

                printf("\033[0m");
            }

            if (i == 1 || i == row)
            {
                for (j = 1; j <= i; j++)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            else
            {
                for (j = 1; j <= i; j++)
                {
                    if (j == 1 || j == i)
                    {
                        // printing colours
                        printf("\033[0;%d;40m", colour);
                        printf("%c", symbol);

                        printf("\033[0m");
                    }
                    else
                    {
                        printf("\033[0;%d;40m", colour);
                        printf(" "); // printing space

                        printf("\033[0m");
                    }
                }
            }
            printf("\n");
        }
    }
}
