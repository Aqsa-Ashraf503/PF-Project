#include "Data_header.h"
// Functions to input the size,symbl,colour
void filled_oval(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int width = row, height = row;
    double h = (double)height / 2;
    double w = (double)width / 2;

    // for left
    if (position == 1)
    {
        
        for (int i = 0; i <= height; i++)
        {
            for (int j = 0; j <= width; j++)
            {
                double distance = pow((j - w) / w, 2) + pow((i - h) / h, 2);
                if (distance <= 0.8)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
        
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                    
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
    }
    // for right
    if (position == 2)
    {
        
        for (int i = 0; i <= height; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j <= width; j++)
            {
                double distance = pow((j - w) / w, 2) + pow((i - h) / h, 2);
                if (distance <= 0.8)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
        
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); 
                   // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
    }
    // for middle
    if (position == 3)
    {
        
        for (int i = 0; i <= height; i++)
        {
            printf("                                                 ");
            for (int j = 0; j <= width; j++)
            {
                double distance = pow((j - w) / w, 2) + pow((i - h) / h, 2);
                if (distance <= 0.8)
                {

                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
        
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); 
                   // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
    }
}

// Functions to input the size,symbl,colour
void hollow_oval(int row, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    int width = row, height = row;
    double h = (double)height / 2;
    double w = (double)width / 2;
    // for left
    if (position == 1)
    {
        
        for (int i = 0; i <= height; i++)
        {
            for (int j = 0; j <= width; j++)
            {
                double distance = pow((j - w) / w, 2) + pow((i - h) / h, 2);
                if (distance >= 0.8 && distance <= 1.2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
        
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" ");
                    // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
    }

    // for right
    if (position == 2)
    {
        
        for (int i = 0; i <= height; i++)
        {
            printf("                                                                                                   ");
            for (int j = 0; j <= width; j++)
            {
                double distance = pow((j - w) / w, 2) + pow((i - h) / h, 2);
                if (distance >= 0.8 && distance <= 1.2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
        
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" ");
                    // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
    }
    // for middle
    if (position == 3)
    {
        
        for (int i = 0; i <= height; i++)
        {
            printf("                                                 ");
            for (int j = 0; j <= width; j++)
            {
                double distance = pow((j - w) / w, 2) + pow((i - h) / h, 2);
                if (distance >= 0.8 && distance <= 1.2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
        
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" ");
                   // printing space
                    printf("\033[0m");
                }
            }
            printf("\n");
           
        }
    }
}

