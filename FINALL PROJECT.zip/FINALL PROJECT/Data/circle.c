#include "Data_header.h"
// Functions to input the size,symbl,colour
void filled_circle(int radius, int colour, char symbol,int position,int choice)
{   
// intializing the variables
    int i;
    int j;
    
// for left
if (position == 1)
    {
      
    for (i = -radius; i <= radius; i++) {
        for (j = -radius; j <= radius; j++) {
            if (sqrt(i * i + j * j) <= radius + 0.5) {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
             
                printf("\033[0m");
            } else {
                printf("  ");
               // Two spaces to maintain spacing in the circle
            }
        }
        printf("\n");
    
    }
   
    }
// for right
if (position == 2)
    {
       
        for (i = -radius; i <= radius; i++){
             printf("                                                                                                   ");
         for (j = -radius; j <= radius; j++) {
            if (sqrt(i * i + j * j) <= radius + 0.5) {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
              
                printf("\033[0m");
            } else {
                printf("  "); 
             // Two spaces to maintain spacing
            }
        }
        printf("\n");
    
        }
       
}

    //for middle
    if (position == 3)
    {
       
       for (i = -radius; i <= radius; i++) {
printf("                                                 ");
               for (j = -radius; j <= radius; j++) {
            if (sqrt(i * i + j * j) <= radius + 0.5) {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
             
                printf("\033[0m");
            } else {
                printf("  ");
              // Two spaces to maintain spacing
            }
        }
        printf("\n");
    
}

    }
}
    
// Functions to input the size,symbl,colour
void hollow_circle(int radius, int colour, char symbol,int position,int choice)
{   
// intializing the variables
    int i;
    int j;
// for left
if (position == 1)
    {
        FILE *done = fopen("hollow_circle.text", "w");
    for (i = -radius; i <= radius; i++) {
        for (j = -radius; j <= radius; j++) {
            double distance = sqrt(i * i + j * j);
            
            if (fabs(distance - radius) < 0.5) {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
             
                printf("\033[0m");
            } else {
                printf("  "); 
             

            }
        }
        printf("\n");
    
    }
   
}

// for right
if (position == 2)
{
    FILE *done = fopen("hollow_circle.text", "w");
    for (i = -radius; i <= radius; i++) {
                     printf("                                                                                                   ");
        for (j = -radius; j <= radius; j++) {
            double distance = sqrt(i * i + j * j);
            
            if (fabs(distance - radius) < 0.5) {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
             
                printf("\033[0m");
            } else {
                printf("  ");
              
            }
        }
        printf("\n");
    
}

}
//for middle
if (position == 3)
{
    FILE *done = fopen("hollow_circle.text", "w");
     for (i = -radius; i <= radius; i++){
          printf("                                                 ");
          for (j = -radius; j <= radius; j++) {
            double distance = sqrt(i * i + j * j);
            
            if (fabs(distance - radius) < 0.5) {
                // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
fprintf(done, "%c", symbol);
                printf("\033[0m");
            } else {
                printf("  "); 
             
            }
        }
        printf("\n");
    
}

}
}

    

