void fish(int row, int colour, char symbol,int position);
