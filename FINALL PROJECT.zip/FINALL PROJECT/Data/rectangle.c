#include "Data_header.h"

// Functions to input the size,symbl,colour
void filled_rectangle(int row, int colour, char symbol, int position)
{
  // intializing the variables
  int i;
  int j;
  int col;

  // for left
  if (position == 1)
  {

    for (i = 0; i < row; i++)
    {
      for (j = 0; j < col; j++)
      {

        // printing colours
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);

        printf("\033[0m");
      }
      printf("\n");
    }
  }
  // for right
  if (position == 2)
  {

    for (i = 0; i < row; i++)
    {
      printf("                                                                                                   ");
      for (j = 0; j < col; j++)
      {

        // printing colours
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);

        printf("\033[0m");
      }
      printf("\n");
    }
  }
  // for middle
  if (position == 3)
  {

    for (i = 0; i < row; i++)
    {
      printf("                                                 ");
      for (j = 0; j < col; j++)
      {

        // printing colours
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);

        printf("\033[0m");
      }
      printf("\n");
    }
  }
}

// Functions to input the size,symbl,colour
void hollow_rectangle(int row, int colour, char symbol, int position)
{
  // intializing the variables
  int i;
  int j;
  int col;
  // for left
  if (position == 1)
  {

    for (int i = 0; i < row; i++)
    {
      for (int j = 0; j < col; j++)

      {
        if (i == 0 || i == row - 1 || j == 0 || j == col - 1)

        { // printing colours
          printf("\033[0;%d;40m", colour);
          printf("%c", symbol);

          printf("\033[0m");
        }

        else
        {

          printf("\033[0;%d;40m", colour);
          printf(" "); // printing space

          printf("\033[0m");
        }
      }
      printf("\n");
    }
  }

  // for right
  if (position == 2)
  {

    for (int i = 0; i < row; i++)
    {
      printf("                                                                                                   ");
      for (int j = 0; j < col; j++)
      {
        if (i == 0 || i == row - 1 || j == 0 || j == col - 1)
        {
          // printing colours
          printf("\033[0;%d;40m", colour);
          printf("%c", symbol);

          printf("\033[0m");
        }
        else
        {
          printf("\033[0;%d;40m", colour);
          printf(" "); // printing space

          printf("\033[0m");
        }
      }
      printf("\n");
    }
  }
  // for middle
  if (position == 3)
  {

    for (int i = 0; i < row; i++)
    {
      printf("                                                 ");
      for (int j = 0; j < col; j++)
      {
        if (i == 0 || i == row - 1 || j == 0 || j == col - 1)
        {
          // printing colours
          printf("\033[0;%d;40m", colour);
          printf("%c", symbol);

          printf("\033[0m");
        }
        else
        {
          printf("\033[0;%d;40m", colour);
          printf(" "); // printing space

          printf("\033[0m");
        }
      }

      printf("\n");
    }
  }
}
