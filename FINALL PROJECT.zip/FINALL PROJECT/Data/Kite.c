#include "Data_header.h"

// Functions to input the size,symbl,colour
void filled_kite(int row, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
    int spaces=row-1;
    
// for left
if (position == 1)
    {
        for (int i = 1; i <= row; i++) {
        for (int j = 1; j <= spaces; j++) 
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
           for (int j = 1; j <= 2 * i - 1; j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
         
        }
        spaces--;
        printf("\n");
        }
         spaces = 1;
    for (int i = row - 1; i >= 1; i--) {
        for (int j = 1; j <= spaces; j++)
        {
            printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");

        }
        for (int j = 1; j <= 2 * i - 1; j++)
        {
             printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");

        
        }
         spaces++;
        printf("\n");
    
    }
    
    
    for(int  i=1;i<=row-3;i++)
        
        
        {
            for( int k=row-1;k>=i;k--)
            {
               printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");

            }
             for(int j=1;j<=i-2;j++)
             {
                 printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
             }
             for(int j=1;j<=i;j++)
             {
              printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");  
             }
             printf("\n");
        }
    }

    
    
// for right
if (position == 2)
    {
        for(i = 1; i <= row; i++)
         {
             printf("                                                                                                   ");
         for (int j = 1; j <= spaces; j++) 
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
           for (int j = 1; j <= 2 * i - 1; j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
         
        }
        spaces--;
        printf("\n");
        }
         spaces = 1;
    for (int i = row - 1; i >= 1; i--) {
        printf("                                                                                                   ");
        for (int j = 1; j <= spaces; j++)
        {
            printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");

        }
        for (int j = 1; j <= 2 * i - 1; j++)
        {
             printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");

        }
         spaces++;
        printf("\n");
    }
    for(int  i=1;i<=row-3;i++)
        
        {
            printf("                                                                                                   ");
            for( int k=row-1;k>=i;k--)
            {
               printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");

            }
             for(int j=1;j<=i-2;j++)
             {
                 printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
             }
             for(int j=1;j<=i;j++)
             {
              printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");  
             }
             printf("\n");
        }
    }
    
    //for middle
    if (position == 3)
    {
        for(i = 1; i <= row; i++) {
printf("                                                 ");
         for (int j = 1; j <= spaces; j++) 
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
           for (int j = 1; j <= 2 * i - 1; j++)
        {
           
        // printing colours
                printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
         
        }
        spaces--;
        printf("\n");
        }
         spaces = 1;
    for (int i = row - 1; i >= 1; i--) {
        printf("                                                 ");
        for (int j = 1; j <= spaces; j++)
        {
            printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");

        }
        for (int j = 1; j <= 2 * i - 1; j++)
        {
             printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");

        }
         spaces++;
        printf("\n");
    }
    for(int  i=1;i<=row-3;i++)
        
        
        {
            printf("                                                 ");
            for( int k=row-1;k>=i;k--)
            {
               printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");

            }
             for(int j=1;j<=i-2;j++)
             {
                 printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
             }
             for(int j=1;j<=i;j++)
             {
              printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");  
             }
             printf("\n");
        }
    }
}
    
// Functions to input the size,symbl,colour
void hollow_kite(int row, int colour, char symbol,int position)
{   
// intializing the variables
    int i;
    int j;
    
// for left

if (position == 1)
    {
  for(int i=1;i<=row;i++) //for row
    {
        for(int j=row-1;j>=i;j--) //for spacing
        {
            printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m"); 
        }
        for(int space=1;space<=i;space++) // for column
    {
        if(space==1 || i==row)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
        }
        else
        {
             printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
    }
    for(int space=1;space<=i;space++)
    {
            if(i==row || space==1 || space==i)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
            }
            else
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
    }
    printf("\n");
    }
    for(i=row;i>=1;i--)
    {
        for(j=row-1;j>=i;j--)
        {
             printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
        for(int space=1;space<=i;space++)
        {
            if(i==1 || space==1)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
            }
            else
             {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
        }
        for(int space=1;space<=i;space++)
        {
            if(space==row || space==i || space==1 || i==1)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
        
            }
            else
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
        }
        printf("\n");
    }
    for(i=1;i<=row;i++) // for a pyramid
    {
       for(j=row-1;j>=i;j--)
       {
         printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
       }
       for(int space=1;space<=i;space++)
       {
        if(space==1 || i==space ||i==row)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
        }
        else
        {
             printf("\033[0;%d;40m", colour);
                printf("  ");//printing space
                printf("\033[0m");
        }
       }
        printf("\n");
    }
    }
    

// for right
if (position == 2)
{
   for(int i=1;i<=row;i++) //for row
    {
        printf("                                                                                                   "); 
        for(int j=row-1;j>=i;j--) //for spacing
        {
            printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m"); 
        }
        for(int space=1;space<=i;space++) // for column
    {
        if(space==1 || i==row)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
        }
        else
        {
             printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
    }
    for(int space=1;space<=i;space++)
    {
            if(i==row || space==1 || space==i)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
            }
            else
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
    }
    printf("\n");
    }
    for(i=row;i>=1;i--)
    {
         printf("                                                                                                   ");
        for(j=row-1;j>=i;j--)
        {
             printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
        for(int space=1;space<=i;space++)
        {
            if(i==1 || space==1)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
            }
            else
             {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
        }
        for(int space=1;space<=i;space++)
        {
            if(space==row || space==i || space==1 || i==1)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
        
            }
            else
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
        }
        printf("\n");
    }
    for(i=1;i<=row;i++) // for a pyramid
    {
       printf("                                                                                                   ");  
       for(j=row-1;j>=i;j--)
       {
         printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
       }
       for(int space=1;space<=i;space++)
       {
        if(space==1 || i==space ||i==row)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
        }
        else
        {
             printf("\033[0;%d;40m", colour);
                printf("  ");//printing space
                printf("\033[0m");
        }
       }
        printf("\n");
    }
}
//for middle
if (position == 3)
{
   for(int i=1;i<=row;i++) //for row
    {
       printf("                                                 "); 
        for(int j=row-1;j>=i;j--) //for spacing
        {
            printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m"); 
        }
        for(int space=1;space<=i;space++) // for column
    {
        if(space==1 || i==row)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
        }
        else
        {
             printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
    }
    for(int space=1;space<=i;space++)
    {
            if(i==row || space==1 || space==i)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
            }
            else
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
    }
    printf("\n");
    }
    for(i=row;i>=1;i--)
    {
        printf("                                                 ");
        for(j=row-1;j>=i;j--)
        {
             printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
        }
        for(int space=1;space<=i;space++)
        {
            if(i==1 || space==1)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
            }
            else
             {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
        }
        for(int space=1;space<=i;space++)
        {
            if(space==row || space==i || space==1 || i==1)
            {
                  printf("\033[0;%d;40m", colour);
                printf("%c", symbol);
                printf("\033[0m");
        
            }
            else
            {
                 printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
            }
        }
        printf("\n");
    }
    for(i=1;i<=row;i++) // for a pyramid
    {
       printf("                                                 "); 
       for(j=row-1;j>=i;j--)
       {
         printf("\033[0;%d;40m", colour);
                printf(" ");//printing space
                printf("\033[0m");
       }
       for(int space=1;space<=i;space++)
       {
        if(space==1 || i==space ||i==row)
        {
              printf("\033[0;%d;40m", colour);
                printf("%c ", symbol);
                printf("\033[0m");
        }
        else
        {
             printf("\033[0;%d;40m", colour);
                printf("  ");//printing space
                printf("\033[0m");
        }
       }
        printf("\n");
    }
}
}
