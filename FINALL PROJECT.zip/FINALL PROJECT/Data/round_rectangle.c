#include "Data_header.h"

// Functions to input the size,symbl,colour
void filled_roundrectangle(int row, int column, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {

        for (i = 1; i <= row; i++)
        {
            for (j = 1; j <= column; j++)
            {
                if (i == 1 && j == 1 || i == 1 && j == column || j == 1 && i == row || i == row && j == column)
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }

    // for right
    if (position == 2)
    {

        for (i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= column; j++)
            {
                if (i == 1 && j == 1 || i == 1 && j == column || j == 1 && i == row || i == row && j == column)
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (i = 1; i <= row; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= column; j++)
            {
                if (i == 1 && j == 1 || i == 1 && j == column || j == 1 && i == row || i == row && j == column)
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space

                    printf("\033[0m");
                }
                else
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
}

// Functions to input the size,symbl,colour
void hollow_roundrectangle(int row, int column, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {

        for (int i = 1; i <= row; i++)
        {
            for (int j = 1; j <= column; j++)
            {

                if (i == 1 && j != 1 && j != column || j == 1 && i != 1 && i != row || j == column && i != 1 && i != row || i == row && j != 1 && j != column)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol); // printing colour

                    printf("\033[0m");
                }
                else
                {
                    // printing space
                    printf("\033[0;%d;40m", colour);
                    printf(" ");

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }

    // for right
    if (position == 2)
    {

        for (int i = 1; i <= row; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= column; j++)
            {

                if (i == 1 && j != 1 && j != column || j == 1 && i != 1 && i != row || j == column && i != 1 && i != row || i == row && j != 1 && j != column)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol); // printing colour

                    printf("\033[0m");
                }
                else
                {
                    // printing space
                    printf("\033[0;%d;40m", colour);
                    printf(" ");

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
    // for middle
    if (position == 3)
    {

        for (int i = 1; i <= row; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= column; j++)
            {

                if (i == 1 && j != 1 && j != column || j == 1 && i != 1 && i != row || j == column && i != 1 && i != row || i == row && j != 1 && j != column)
                {
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol); // printing colour

                    printf("\033[0m");
                }
                else
                {
                    // printing space
                    printf("\033[0;%d;40m", colour);
                    printf(" ");

                    printf("\033[0m");
                }
            }
            printf("\n");
        }
    }
}
