#include "Data_header.h"
// Functions to input the size,symbl,colour
void fish(int row, int colour, char symbol, int position)
{
  // intializing the variables
  int i, j, k, l, n = row;
  j = row;
  l = row;
  k = row;

  // for left
  if (position == 1)
  {
    ;
    for (i = 1; i <= n; i++)
    {
      for (j = 1; j <= n - i; j++)
      {

        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (k = 1; k <= 2 * i - 1; k++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      for (j = 1; j <= 2 * (n - i); j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (l = 3; l <= i; l++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      printf("\n");
    }
    for (i = n - 1; i >= 1; i--)
    {

      for (j = 1; j <= n - i; j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (k = 1; k <= 2 * i - 1; k++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      for (j = 1; j <= 2 * (n - i); j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (l = 3; l <= i; l++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      printf("\n");
        
    }

  }
  // for right
  if (position == 2)
  {
    ;
    for (i = 1; i <= n; i++)

    {

      printf("                                                                                                   ");
      for (j = 1; j <= n - i; j++)
      {

        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (k = 1; k <= 2 * i - 1; k++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      for (j = 1; j <= 2 * (n - i); j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (l = 3; l <= i; l++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      printf("\n");
        
    }

    for (i = n - 1; i >= 1; i--)
    {
      printf("                                                                                                   ");
      for (j = 1; j <= n - i; j++)
      {

        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (k = 1; k <= 2 * i - 1; k++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      for (j = 1; j <= 2 * (n - i); j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (l = 3; l <= i; l++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      printf("\n");
        
    }

  }

  // for middle
  if (position == 3)
  {
    ;
    for (i = 1; i <= n; i++)
    {
      printf("                                                 ");

      for (j = 1; j <= n - i; j++)
      {

        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (k = 1; k <= 2 * i - 1; k++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      for (j = 1; j <= 2 * (n - i); j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (l = 3; l <= i; l++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      printf("\n");
        
    }

    for (i = n - 1; i >= 1; i--)
    {
      printf("                                                 ");
      for (j = 1; j <= n - i; j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (k = 1; k <= 2 * i - 1; k++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      for (j = 1; j <= 2 * (n - i); j++)
      {
        printf("\033[0;%d;40m", colour);
        printf(" "); // printing space
        
        printf("\033[0m");
      }
      for (l = 3; l <= i; l++)
      {
        printf("\033[0;%d;40m", colour);
        printf("%c", symbol);
         
        printf("\033[0m");
      }
      printf("\n");
        
    }

  }
}