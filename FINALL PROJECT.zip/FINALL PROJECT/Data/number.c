#include "Data_header.h"
// Functions to input the size,symbl,colour
void print_0(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;

    // for left
    if (position == 1)
    {
       
        for (i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
       
        for (i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
       
        for (i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || j == 1 && i != 1 && i != size || j == size && i != 1 && i != size || i == size && j != 1 && j != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_1(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("1.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (j == size / 2 + 1 || j == size / 2 - 1 && i == 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }

    // for right
    if (position == 2)
    {
        FILE *done = fopen("1.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (j == size / 2 + 1 || j == size / 2 - 1 && i == 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("1.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (j == size / 2 + 1 || j == size / 2 - 1 && i == 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_2(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // outer loop for the letter X
    if (position == 1)
    {
        FILE *done = fopen("2.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i + j == size + 1 && j != size || i == size || i == 1 && j != size && j != 1 && j != 1 && j != size - 1 || i == 2 && j == 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("2.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i + j == size + 1 && j != size || i == size || i == 1 && j != size && j != 1 && j != 1 && j != size - 1 || i == 2 && j == 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }

    // for middle
    if (position == 3)
    {
        FILE *done = fopen("2.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i + j == size + 1 && j != size || i == size || i == 1 && j != size && j != 1 && j != 1 && j != size - 1 || i == 2 && j == 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_3(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("3.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j <= size / 2 + (size / 2 - 1) && j != 1 || i == size / 2 && j <= size / 2 + (size / 2 - 1) && j != 1 || i == size && j <= size / 2 + (size / 2 - 1) && j != 1 || j == size && i < size / 2 && i != 1 || j == size && i > size / 2 && i != size || i == 2 && j == 1 || i == size - 1 && j == 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("3.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j <= size / 2 + (size / 2 - 1) && j != 1 || i == size / 2 && j <= size / 2 + (size / 2 - 1) && j != 1 || i == size && j <= size / 2 + (size / 2 - 1) && j != 1 || j == size && i < size / 2 && i != 1 || j == size && i > size / 2 && i != size || i == 2 && j == 1 || i == size - 1 && j == 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("3.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j <= size / 2 + (size / 2 - 1) && j != 1 || i == size / 2 && j <= size / 2 + (size / 2 - 1) && j != 1 || i == size && j <= size / 2 + (size / 2 - 1) && j != 1 || j == size && i < size / 2 && i != 1 || j == size && i > size / 2 && i != size || i == 2 && j == 1 || i == size - 1 && j == 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_4(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("4.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (j == size - 1 && i != 1 || i + j == size + 1 && j != size && i != size || i == size - 1 && j != 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("4.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (j == size - 1 && i != 1 || i + j == size + 1 && j != size && i != size || i == size - 1 && j != 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("4.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (j == size - 1 && i != 1 || i + j == size + 1 && j != size && i != size || i == size - 1 && j != 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_5(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("5.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 || i == size / 2 && j != size || i == size && j != size || j == size && i >= size / 2 + 1 && i != size || j == 1 && i < size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("5.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 || i == size / 2 && j != size || i == size && j != size || j == size && i >= size / 2 + 1 && i != size || j == 1 && i < size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("5.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 || i == size / 2 && j != size || i == size && j != size || j == size && i >= size / 2 + 1 && i != size || j == 1 && i < size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_6(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("6.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 || j == 1 && i != 1 && i != size || i == size / 2 && j != size || i == size && j != 1 && j != size || j == size && i >= size / 2 + 1 && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("6.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 || j == 1 && i != 1 && i != size || i == size / 2 && j != size || i == size && j != 1 && j != size || j == size && i >= size / 2 + 1 && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("6.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 || j == 1 && i != 1 && i != size || i == size / 2 && j != size || i == size && j != 1 && j != size || j == size && i >= size / 2 + 1 && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_7(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("7.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 || i + j == size + 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("7.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 || i + j == size + 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("7.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 || i + j == size + 1)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_8(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("8.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || i == size / 2 && j != 1 && j != size || i == size && j != 1 && j != size || j == 1 && i != 1 && i != size && i != size / 2 || j == size && i != 1 && i != size && i != size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("8.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || i == size / 2 && j != 1 && j != size || i == size && j != 1 && j != size || j == 1 && i != 1 && i != size && i != size / 2 || j == size && i != 1 && i != size && i != size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("8.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || i == size / 2 && j != 1 && j != size || i == size && j != 1 && j != size || j == 1 && i != 1 && i != size && i != size / 2 || j == size && i != 1 && i != size && i != size / 2)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}

// Functions to input the size,symbl,colour
void print_9(int size, int colour, char symbol, int position)
{
    // intializing the variables
    int i;
    int j;
    // for left
    if (position == 1)
    {
        FILE *done = fopen("9.text", "w");
        for (int i = 1; i <= size; i++)
        {
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || i == size / 2 + 1 && j != 1 && j != size - 1 || i == size && j != size || j == 1 && i <= size / 2 && i != 1 || j == size && i != 1 && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for right
    if (position == 2)
    {
        FILE *done = fopen("9.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                                                                   ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || i == size / 2 + 1 && j != 1 && j != size - 1 || i == size && j != size || j == 1 && i <= size / 2 && i != 1 || j == size && i != 1 && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
    // for middle
    if (position == 3)
    {
        FILE *done = fopen("9.text", "w");
        for (int i = 1; i <= size; i++)
        {
            printf("                                                 ");
            for (int j = 1; j <= size; j++)
            {
                if (i == 1 && j != 1 && j != size || i == size / 2 + 1 && j != 1 && j != size - 1 || i == size && j != size || j == 1 && i <= size / 2 && i != 1 || j == size && i != 1 && i != size)
                {
                    // printing colours
                    printf("\033[0;%d;40m", colour);
                    printf("%c", symbol);
                    
                    printf("\033[0m");
                }
                else
                {
                    printf("\033[0;%d;40m", colour);
                    printf(" "); // printing space
                   
                    printf("\033[0m");
                }
            }
            printf("\n");
            
        }
       
    }
}