#include "interface_header.h"

struct shape
{
    int size;
    int row;
    char symbol;
    char choice;
    int column;
    int position;
    int colour;
    int col;
    int radius;
    int triangleType;
    int fillType;
};

void run_main_menu()
{
    struct shape a1;
    a1.row;
    printf("%d", a1.row);
    printf("|----------------------------------------------------------------------------|\n");
    printf("|                          WELCOME TO MS PAINT:                              |\n");
    printf("|----------------------------------------------------------------------------|\n");
    printf("\n");
    while (1)
    {

        int choice;
        printf("|----------------------------------------------------------------------------|\n");
        printf("|                                 Options                                     |\n");
        printf("|----------------------------------------------------------------------------|\n");
        printf("\n");
        printf("1) Press 1 to make shapes\n");
        printf("2) Press 2 to draw on terminal\n");
        printf("3) Press 3 to save the file\n");
        printf("4) Press 4 to view the existing file\n");
        printf("5) Press 5 to edit an existing file\n");
        printf("Q) Press 0 to exit\n");
        scanf("%d", &choice);

        int custom;
        if (choice == 0)
        {

            printf("You are out of the programme.");
            break;
        }
        if (choice == 1)

        {
            printf("Press 1 to go to Alphabets Interface\n");
            printf("Press 2 to go to Number Interface\n");
            printf("Press 3 to go to Square Interface\n");
            printf("Press 4 to go to Hexagon Interface\n");
            printf("Press 5 to go to Trapizum Interface\n");
            printf("Press 6 to go to Parallelogram Interface\n");
            printf("Press 7 to go to Butterfly Interface\n");
            printf("Press 8 to go to Fish Interface\n");
            printf("Press 9 to go to Rectangle Interface\n");
            printf("Press 10 to go to Pentagon Interface\n");
            printf("Press 11 to go to Lines Interface\n");
            printf("Press 12 to go to Round_Reactangle Interface\n");
            printf("Press 13 to go to Triangle Interface\n");
            printf("Press 14 to go to Circle Interface\n");
            printf("Press 15 to go to Oval Interface\n");
            printf("Press 16 to go to Plus Interface\n");
            printf("Press 17 to go to Pencil Interface\n");
            printf("Press 18 to go to Hut Interface\n");
            printf("Press 19 to go to Minar_e_Pakistan Interface\n");
            printf("Press 20 to go to Heart Interface\n");
            printf("Press 21 to go to Diamond Interface\n");
            printf("Press 22 to go to Pyramid Interface\n");
            printf("Press 23 to go to arrow Interface\n");

            printf("Press -1 to exit\n");
            scanf("%d", &custom);
            switch (custom)
            {
            case 1:
                Alphabets_interface();
                break;
            case 2:
                number_interface();
                break;
            case 3:
                square_interface();
                break;
            case 4:
                hexagon_interface();
                break;
            case 5:
                trapizum_interface();
                break;
            case 6:
                paralellogram_interface();
                break;
            case 7:
                butterfly_interface();
                break;
            case 8:
                fish_interface();
                break;
            case 9:
                rectangle_interface();
                break;
            case 10:
                pentagon_interface();
                break;
            case 11:
                lines_interface();
                break;
            case 12:
                round_rectangle_interface();
                break;
            case 13:
                Triangle_interface();
                break;
            case 14:
                circle_interface();
                break;
            case 15:
                Oval_interface();
                break;
            case 16:
                Plus_interface();
                break;
            case 17:
                Pencil_interface();
                break;
            case 18:
                Hut_interface();
                break;
            case 19:
                minar_e_pakistan_interface();
                break;
            case 20:
                heart_interface();
                break;
            case 21:
                diamond_interface();
                break;
            case 22:

                pyramid_interface();
                break;
            case 23:
                arrow_interface();
                break;
            }
        }
        else if (choice == 2)
        {
            free_hand_interface();
        }
        else if (choice == 3)
        {
            save_interface();
        }
        else if (choice == 4)
        {
            view_interface();
        }
        else if (choice == 5)
        {
            editExistingFile();
        }
    }
}
void main_menue()
{
    int choice;
}

void Alphabets_interface()
{
    int size, position, col, colour;
    char symbol, start, last;
    
    printf("Print Alphabets: \n");
    printf("enter the start character:\n ");
    scanf(" %c", &start);

    printf("enter the last character:\n ");
    scanf(" %c", &last);

    printf("Enter the size of character: ");
    scanf("%d", &size);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    // printf("Enter the character choice (A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z): ");
    // scanf(" %c", &choice);

    print_character(size, col, colour, symbol, position, start, last);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void number_interface()
{
    int size, position, colour, first, last;
    char symbol;

    printf("enter the start character:\n ");
    scanf(" %d", &first);

    printf("enter the last character:\n ");
    scanf(" %d", &last);
    printf("Print Numbers:\n");
    printf("Enter the size of character: ");
    scanf("%d", &size);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    print_number(size, colour, symbol, position, first, last);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void square_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Square:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_square(row, colour, symbol, position, choice);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void square_save()
{
    int row, position, colour;
    char symbol, choice;
    char filename[50] = "squaretxt";
    FILE *done = fopen("squaretxt", "w");
    struct shape a1[100];
    int i = 0;
    printf("Print Square:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    a1[i].row = row;
    a1[i].symbol = symbol;
    a1[i].colour = colour;
    a1[i].position = position;
    a1[i].choice = choice;

    fprintf(done, "a1[i].size=%d\n", row);
    fprintf(done, "a1[i].colour=%d\n", colour);
    fprintf(done, "a1[i].symbol=%c\n", symbol);
    fprintf(done, "a1[i].choice=%d\n", choice);
    fprintf(done, "a1[i].position=%d\n", position);

    print_square(row, colour, symbol, position, choice);
    fclose(done);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void hexagon_interface()
{
    int row, position, colour;
    char symbol, choice;

    printf("Print Hexagon:\n");
    printf("Enter the size of character:\n ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print:\n ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position:\n ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow):\n ");
    scanf(" %c", &choice);

    print_hexagon(row, colour, symbol, position, choice);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void hexagon_save()
{
    int row, position, colour;
    char symbol, choice;
    char filename[50] = "hexagontxt";
    FILE *done = fopen("hexagontxt", "w");
    struct shape a2[100];
    int i = 0;

    printf("Print Hexagon:\n");
    printf("Enter the size of character:\n ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print:\n ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position:\n ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow):\n ");
    scanf(" %c", &choice);
    a2[i].row = row;
    a2[i].symbol = symbol;
    a2[i].colour = colour;
    a2[i].position = position;
    a2[i].choice = choice;

    fprintf(done, "a2[i].size=%d\n", row);
    fprintf(done, "a2[i].colour=%d\n", colour);
    fprintf(done, "a2[i].symbl=%c\n", symbol);
    fprintf(done, "a2[i].choice=%d\n", choice);
    fprintf(done, "a2[i].position=%d\n", position);

    print_hexagon(row, colour, symbol, position, choice);
    fclose(done);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void trapizum_interface()
{
    int row, colour, position;
    char symbol, choice;
    printf("Print Trapizum:\n");

    printf("Enter the size of character:\n ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print:\n ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position:\n ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow 3 for reverse 4 for reverse hollow):\n ");
    scanf(" %c", &choice);

    print_trapizum(row, colour, symbol, position, choice);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void trapizum_save()
{
    int row, position, colour;
    char symbol, choice;
    char filename[50] = "trapeziumtxt";
    FILE *done = fopen("trapeziumtxt", "w");
    struct shape a3[100];
    int i = 0;
    printf("Print Trapizum:\n");

    printf("Enter the size of character:\n ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print:\n ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position:\n ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow 3 for reverse 4 for reverse hollow):\n ");
    scanf(" %c", &choice);
    a3[i].row = row;
    a3[i].symbol = symbol;
    a3[i].colour = colour;
    a3[i].position = position;
    a3[i].choice = choice;

    fprintf(done, "a3[i].size=%d\n", row);
    fprintf(done, "a3[i].colour=%d\n", colour);
    fprintf(done, "a3[i].symbol=%c\n", symbol);
    fprintf(done, "a3[i].choice=%d\n", choice);
    fprintf(done, "a3[i].position=%d\n", position);

    print_trapizum(row, colour, symbol, position, choice);
    fclose(done);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void paralellogram_interface()
{
    int row, column, position, colour;
    char symbol, choice;
    printf("Print Paralellogram:\n");
    printf("Enter the size of character:\n ");
    scanf("%d", &row);

    printf("Enter the column of character:\n ");
    scanf("%d", &column);

    printf("Enter the symbol you want to print:\n ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position:\n ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow):\n ");
    scanf(" %c", &choice);

    print_paralellogram(row, column, colour, symbol, position, choice);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void butterfly_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Butterfly:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_butterfly(row, colour, symbol, position, choice);
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void butterfly_save()
{
    int row, position, colour;
    char symbol, choice;
    char filename[50] = "butterflytxt";
    FILE *done = fopen("butterflytxt", "w");
    struct shape a4[100];
    int i = 0;
    printf("Print Butterfly:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);
    a4[i].row = row;
    a4[i].symbol = symbol;
    a4[i].colour = colour;
    a4[i].position = position;
    a4[i].choice = choice;

    fprintf(done, "a4[i].size=%d\n", row);
    fprintf(done, "a4[i].colour=%d\n", colour);
    fprintf(done, "a4[i].symbol=%c\n", symbol);
    fprintf(done, "a4[i].choice=%d\n", choice);
    fprintf(done, "a4[i].position=%d\n", position);

    print_butterfly(row, colour, symbol, position, choice);
    fclose(done);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void fish_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Fish:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    print_fish(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void rectangle_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Rectangle:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_reactangle(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void rectangle_save()
{
    int row, position, colour;
    char symbol, choice;
    char filename[50] = "rectangletxt";
    FILE *done = fopen("rectangletxt", "w");
    struct shape a5[100];
    int i = 0;
    printf("Print Rectangle:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);
    a5[i].row = row;
    a5[i].symbol = symbol;
    a5[i].colour = colour;
    a5[i].position = position;
    a5[i].choice = choice;

    fprintf(done, "a5[i].size=%d\n", row);
    fprintf(done, "a5[i].colour=%d\n", colour);
    fprintf(done, "a5[i].symbl=%c\n", symbol);
    fprintf(done, "a5[i].choice=%d\n", choice);
    fprintf(done, "a5[i].position=%d\n", position);

    print_reactangle(row, colour, symbol, position, choice);
    fclose(done);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void pentagon_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Pentagon:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_pentagon(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void lines_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Lines:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for  horizontal 2 for vertical): ");
    scanf(" %c", &choice);

    print_line(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void round_rectangle_interface()
{
    int row, column, position, colour;
    char symbol, choice;
    printf("Print Round rectangle:\n");
    printf("Enter the size of character:\n ");
    scanf("%d", &row);

    printf("Enter the column of character:\n ");
    scanf("%d", &column);

    printf("Enter the symbol you want to print:\n ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position:\n ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow):\n ");
    scanf(" %c", &choice);

    print_round_rectangle(row, column, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void Triangle_interface()
{
    int row, position, colour, triangleType, fillType;
    char symbol, choice;
    printf("Print Triangle:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the triangle type (1 for inverted right 2 for right triangle 3 for mirrored 4 for inverted mirrored): ");
    scanf(" %c", &triangleType);

    printf("Enter the fill type(1 for hollow 2 for filled): ");
    scanf(" %c", &fillType);

    print_Triangle(row, colour, symbol, position, triangleType, fillType);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void circle_interface()
{
    int radius, position, colour;
    char symbol, choice;
    printf("Print Circle:\n");
    printf("Enter the radius of circle: ");
    scanf("%d", &radius);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_circle(radius, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void circle_save()
{
    int radius, position, colour;
    char symbol, choice;
    char filename[50] = "circletxt";
    FILE *done = fopen("circletxt", "w");
    struct shape a6[100];
    int i = 0;
    printf("Print Circle:\n");
    printf("Enter the radius of circle: ");
    scanf("%d", &radius);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);
    a6[i].radius = radius;
    a6[i].symbol = symbol;
    a6[i].colour = colour;
    a6[i].position = position;
    a6[i].choice = choice;

    fprintf(done, "a6[i].size=%d\n", radius);
    fprintf(done, "a6[i].colour=%d\n", colour);
    fprintf(done, "a6[i].symbol=%c\n", symbol);
    fprintf(done, "a6[i].choice=%d\n", choice);
    fprintf(done, "a6[i].position=%d\n", position);

    print_circle(radius, colour, symbol, position, choice);
    fclose(done);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void Oval_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Oval:\n");
    printf("Enter the size of oval: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the oval choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_oval(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void Oval_save()
{
    int row, position, colour;
    char symbol, choice;
    char filename[50] = "ovaltxt";
    FILE *done = fopen("ovaltxt", "w");
    struct shape a7[100];
    int i = 0;

    printf("Print Oval:\n");
    printf("Enter the size of oval: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the oval choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);
    a7[i].row = row;
    a7[i].symbol = symbol;
    a7[i].colour = colour;
    a7[i].position = position;
    a7[i].choice = choice;

    fprintf(done, "a7[i].size=%d\n", row);
    fprintf(done, "a7[i].colour=%d\n", colour);
    fprintf(done, "a7[i].symbol=%c\n", symbol);
    fprintf(done, "a7[i].choice=%d\n", choice);
    fprintf(done, "a7[i].position=%d\n", position);

    print_oval(row, colour, symbol, position, choice);
    fclose(done);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void Plus_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Plus:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    print_plus(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void Pencil_interface()
{

    int row, position, colour;
    char symbol, choice;
    printf("Print Pencil:\n");
    printf("Enter the size of pencil: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    print_pencil(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void Hut_interface()
{

    int row, position, colour;
    char symbol, choice;
    printf("Print Hut:\n");
    printf("Enter the size of hut: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    print_hut(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void minar_e_pakistan_interface()
{

    int row, position, colour;
    char symbol, choice;
    printf("Print Minare:\n");
    printf("Enter the size of minarepakistan: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    minar_e_pakistan(row, colour, symbol, position);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void heart_interface()
{

    int row, position, colour;
    char symbol, choice;
    printf("Print Heart:\n");
    printf("Enter the size of heart: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the heart choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_heart(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void diamond_interface()
{

    int row, position, colour;
    char symbol, choice;
    printf("Print Diamond:\n");
    printf("Enter the rows of diamond: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the diamond choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_diamond(row, symbol, position, colour, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void pyramid_interface()
{
    int row, position, colour;
    char symbol, choice;
    printf("Print Pyramid:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice(1 for hollow 2 for reverse hollow 3 for filed 4 for reverse filled): ");
    scanf(" %c", &choice);

    print_pyramid(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void arrow_interface()
{
    int row, size, position, colour;
    char symbol, choice;
    printf("Print arrow:\n");
    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);
    printf("Enter the size : ");
    scanf(" %d", &size);

    printf("Enter 1 for left position, 2 for right position, 3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice(1 for down 2 for left 3 for right 4 for up): ");
    scanf(" %c", &choice);

    print_arrow(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void kite_interface()
{
    int row, colour, position;
    char symbol, choice;

    printf("Enter the size of character: ");
    scanf("%d", &row);

    printf("Enter the symbol you want to print: ");
    scanf(" %c", &symbol);

    printf("Enter 1 for left position,2 for right position,3 for middle position: ");
    scanf(" %d", &position);

    printf("Enter the color code:\n");
    printf("30 for Black\n31 for Red\n32 for Green\n33 for Yellow\n34 for Blue\n35 for Magenta\n36 for Cyan\n37 for White\n");
    scanf("%d", &colour);

    printf("Enter the character choice (1 for fill 2 for hollow): ");
    scanf(" %c", &choice);

    print_kite(row, colour, symbol, position, choice);

    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void free_hand_interface()
{
    int x = 40, y = 20;
    char key;
    gotoxy(x, y);
    printf("*");
    while (1)
    {
        key = getch();

        if (key == 75)
        {
            x--;
        }
        else if (key == 77)
        {
            x++;
        }
        else if (key == 72)
        {
            y--;
        }
        else if (key == 80)
        {
            y++;
        }
        else if (key == 27)
        {
            exit(0);
        }

        gotoxy(x, y);
        printf(" ");

        if (key == 32 || key == 98 || key == 114 || key == 121 || key == 103)
        {

            if (key == 75 || key == 32)
            {
                printf("\033[0;29m*\033]0m\n");
            }
            else if (key == 77 || key == 98)
            {
                printf("\033[0;34m*\033]0m\n");
            }
            else if (key == 72 || key == 114)
            {
                printf("\033[0;31m*\033]0m\n");
            }
            else if (key == 80 || key == 121)
            {
                printf("\033[0;33m*\033]0m\n");
            }
            else if (key == 75 || key == 77 || key == 72 || key == 80 || key == 103)
            {
                printf("\033[0;32m*\033]0m\n");
            }
            else if (key == 27)
            {
                exit(0);
            }

            gotoxy(x, y);
            printf("*");
        }
    }
    getch();
}

void gotoxy(int x, int y)
{
    COORD c;
    c.X = x;
    c.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

void save_interface()
{
    int opt = 0;

    printf("1) Enter 1 to Print and Safe ur Square.\n");
    printf("2) Enter 2 to Print and Safe ur  Hexagon.\n");
    printf("3) Enter 3 to Print and Safe ur  Trapezium.\n");
    printf("4) Enter 4 to Print and Safe ur Butterfly.\n");
    printf("5) Enter 5 to Print and Safe ur Rectangle.\n");
    printf("6) Enter 6 to Print and Safe ur Circle.\n");
    printf("7) Enter 7 to Print and Safe ur Oval.\n");
    scanf("%d", &opt);
    if (opt == 1)
    {
        square_save();
    }
    else if (opt == 2)
    {
        hexagon_save();
    }
    else if (opt == 3)
    {
        trapizum_save();
    }
    else if (opt == 4)
    {
        butterfly_save();
    }
    else if (opt == 5)
    {
        rectangle_save();
    }
    else if (opt == 6)
    {
        circle_save();
    }
    else if (opt == 7)
    {
        Oval_save();
    }
    else
    {
        printf("Enter any valid choice.\n");
    }
}
// Assuming you have a global variable to keep track of the current file name
char currentFileName[50];

void view_interface()
{
    printf("View Interface\n");
    printf("Enter the name of the file you want to view: ");
    scanf("%s", currentFileName);

    // Open the file for reading
    FILE *file = fopen(currentFileName, "r");

    if (file)
    {
        char line[100];
        while (fgets(line, sizeof(line), file))
        {
            printf("%s", line);
        }
        fclose(file);
    }
    else
    {
        printf("File '%s' does not exist.\n", currentFileName);
    }
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}

void editExistingFile()
{
    printf("Edit Existing File\n");
    printf("Enter the name of the file you want to edit: ");
    scanf("%s", currentFileName);

    // Open the file for appending
    FILE *file = fopen(currentFileName, "a");

    if (file)
    {
        // Prompt the user for their drawing and save it to the file
        printf("Enter your drawing:\n");
        char drawing[100];
        scanf(" %[^\n]", drawing);
        fprintf(file, "%s\n", drawing);

        fclose(file);
    }
    else
    {
        printf("File '%s' does not exist.\n", currentFileName);
    }
    int option;
    while (1)
    {
        printf("Enter -1 to return to the main menu:\nEnter 0 to quit the program:\n");

        scanf(" %d", &option);

        if (option == -1)
        {
            run_main_menu();
        }
        else if (option == 0)
        {
            exit(0);
        }
    }
}
void quit_interface()
{
    printf("Exiting program...\n");

    int choice;
    while (1)
    {
        // ...
        printf("Q) Press 0 to exit\n");
        char option;
        scanf(" %c", &option); // Notice the space before %c to consume any leading whitespace

        if (option == '0')
        {
            quit_interface();
            break;
        }
    }
}
