#include "Brain_header.h"

void print_character(int size, int col, int colour, char symbol, int position, char start, char last)
{
    for(char i=start;i<=last;i++)
    {
    if (i=='a')
    {
        char_of_A(size, col, colour, symbol, position);
    }
    else if(i=='b')
        char_of_B(size, col, colour, symbol, position);
        
    else if (i=='c')
        char_of_C(size, col, colour, symbol, position);
        
    else if(i=='d')
        char_of_D(size, col, colour, symbol, position);
        
    else if(i=='e')
        char_of_E(size, col, colour, symbol, position);
        
    else if(i=='f')
        char_of_F(size, col, colour, symbol, position);
        
    else if(i=='g')
        char_of_G(size, col, colour, symbol, position);
        
    else if(i=='h')
        char_of_H(size, col, colour, symbol, position);
        
    else if(i=='i')
        char_of_I(size, col, colour, symbol, position);
        
    else if(i=='j')
        char_of_J(size, col, colour, symbol, position);
        
    else if(i=='k')
        char_of_K(size, col, colour, symbol, position);
        
    else if(i=='l')
        char_of_L(size, col, colour, symbol, position);
        
    else if(i=='m')
        char_of_M(size, col, colour, symbol, position);

        else if(i=='n')
        char_of_N(size,col,colour,symbol,position);
        
    else if(i=='o')
        char_of_O(size, col, colour, symbol, position);
        
    else if(i=='p')
        char_of_P(size, col, colour, symbol, position);
        
    else if(i=='q')
        char_of_Q(size, col, colour, symbol, position);
        
    else if(i=='r')
        char_of_R(size, col, colour, symbol, position);
        
    else if(i=='s')
        char_of_S(size, col, colour, symbol, position);
        
    else if(i=='t')
        char_of_T(size, col, colour, symbol, position);
        
    else if(i=='u')
        char_of_U(size, col, colour, symbol, position);
        
    else if(i=='v')
        char_of_V(size, col, colour, symbol, position);
        
    else if(i=='w')
        char_of_W(size, col, colour, symbol, position);
    else if(i=='x')
        char_of_X(size, col, colour, symbol, position);
        
    else if(i=='y')
        char_of_Y(size, col, colour, symbol, position);
        
     else if(i=='z')
        char_of_Z(size, col, colour, symbol, position);
        

    else
        printf("Invalid choice\n");
        
    }
}

void print_number(int size, int colour, char symbol, int position,int first,int last)
{
   for(int i=first;i<=last;i++)
   if(i==0)
        print_0(size, colour, symbol, position);
        
    else if(i==1)
        print_1(size, colour, symbol, position);
    else if(i==2)
        print_2(size, colour, symbol, position);
    else if(i==3)
        print_3(size, colour, symbol, position);
    else if(i==4)
        print_4(size, colour, symbol, position);
    else if(i==5)
        print_5(size, colour, symbol, position);
    else if(i==6)
        print_6(size, colour, symbol, position);
    else if(i==7)
        print_7(size, colour, symbol, position);
    else if(i==8)
        print_8(size, colour, symbol, position);
    else if(i==9)
        print_9(size, colour, symbol, position);

    else
        printf("Invalid choice\n");
    }

void print_square(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_square(row, colour, symbol, position);
        break;
    case '2':
        hollow_square(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_hexagon(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_hexagon(row, colour, symbol, position);
        break;
    case '2':
        hollow_hexagon(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_trapizum(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_trapizum(row, colour, symbol, position);
        break;
    case '2':
        hollow_trapizum(row, colour, symbol, position);
        break;
    case '3':
        reverse_filled_trapizum(row, colour, symbol, position);
        break;
    case '4':
        reverse_hollow_trapizum(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_paralellogram(int row, int column, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_paralellogram(row, column, colour, symbol, position);
        break;
    case '2':
        hollow_paralellogram(row, column, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}
void print_butterfly(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_butterfly(row, colour, symbol, position);
        break;
    case '2':
        hollow_butterfly(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_fish(int row, int colour, char symbol, int position, char choice)

{
    fish(row, colour, symbol, position);
}
void print_reactangle(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_rectangle(row, colour, symbol, position);
        break;
    case '2':
        hollow_rectangle(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_pentagon(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_pentagon(row, colour, symbol, position);
        break;
    case '2':
        hollow_pentagon(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_line(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        horizontal_line(row, colour, symbol, position);
        break;
    case '2':
        vertical_line(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_round_rectangle(int row, int column, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_roundrectangle(row, column, colour, symbol, position);
        break;
    case '2':
        hollow_roundrectangle(row, column, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_Triangle(int row, int colour, char symbol, int position, int triangleType, int fillType)
{

    switch (triangleType)
    {
    case '1':
        if (fillType == '1')
            inverse_right_triangle_filled(row, colour, symbol, position);
        else if (fillType == '2')
            inverse_right_triangle_hollow(row, colour, symbol, position);
        break;
    case '2':
        if (fillType == '1')
            right_triangle_filled(row, colour, symbol, position);
        else if (fillType == '2')
            right_triangle_hollow(row, colour, symbol, position);
        break;
    case '3':
        if (fillType == '1')
            filled_mirrored_triangle(row, colour, symbol, position);
        else if (fillType == '2')
            hollow_mirrored_triangle(row, colour, symbol, position);
        break;
    case '4':
        if (fillType == '1')
            hollow_inverted_mirrored_triangle(row, colour, symbol, position);
        else if (fillType == '2')
            filled_inverted_mirrored_triangle(row, colour, symbol, position);
        break;
    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_circle(int radius, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_circle(radius, colour, symbol, position, choice);
        break;
    case '2':
        hollow_circle(radius, colour, symbol, position, choice);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}
void print_oval(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_oval(row, colour, symbol, position);
        break;
    case '2':
        hollow_oval(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}
void print_plus(int row, int colour, char symbol, int position, char choice)
{

    plus_sign(row, colour, symbol, position);
}
void print_pencil(int row, int colour, char symbol, int position, char choice)
{

    pencil(row, colour, symbol, position);
}
void print_hut(int row, int colour, char symbol, int position, char choice)
{

    hut(row, colour, symbol, position);
}

void print_minar_e_pakistan(int row, int colour, char symbol, int position, char choice)
{

    minar_e_pakistan(row, colour, symbol, position);
}
void print_heart(int n, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_heart(n, colour, symbol, position);
        break;
    case '2':
        hollow_heart(n, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}
void print_diamond(int row, char symbol, int position, int colour, char choice)
{
    switch (choice)
    {
    case '1':
        printf("filled diamond");
        filled_diamond(row, colour, symbol, position);
        break;
    case '2':
        printf("hollow diamond");
        hollow_diamond(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_pyramid(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        hollow_pyramid(row, colour, symbol, position);
        break;
    case '2':
        hollow_reverse_pyramid(row, colour, symbol, position);
        break;

    case '3':
        filled_pyramid(row, colour, symbol, position);
        break;
    case '4':
        filled_reverse_pyramid(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

void print_arrow(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        down_arrow(row, colour, symbol, position);
        break;
    case '2':
        left_arrow(row, colour, symbol, position);
        break;
    case '3':
        right_arrow(row, colour, symbol, position);
        break;
    case '4':
        up_arrow(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}

/*void print_shape(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_squareT(row, colour, symbol, position);
        break;
    case '2':
        hollow_squareT(row, colour, symbol, position);
        break;
    case '3':
        filled_rectangleT(row, colour, symbol, position);
        break;
    case '4':
        hollow_rectangleT(row, colour, symbol, position);
        break;
    case '5':
        filled_hexagonT(row, colour, symbol, position);
        break;
    case '6':
        hollow_hexagonT(row, colour, symbol, position);
        break;

    case '7':
        hollow_pentagonT(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}*/
void print_kite(int row, int colour, char symbol, int position, char choice)
{
    switch (choice)
    {
    case '1':
        filled_kite(row, colour, symbol, position);
        break;
    case '2':
        hollow_kite(row, colour, symbol, position);
        break;

    default:
        printf("Invalid choice\n");
        break;
    }
}